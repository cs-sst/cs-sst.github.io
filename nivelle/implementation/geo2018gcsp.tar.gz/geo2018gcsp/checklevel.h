
// Written by Hans de Nivelle, 15 january 2017.
// I think there is no point in distinguishing
// more check levels. Using a separate type
// has the advantage that one can easily search for it. 


#ifndef CHECKLEVEL_INCLUDED
#define CHECKLEVEL_INCLUDED  1

#include <iostream>

enum class checklevel
{
   forfree = 0,     // Checks only what can be checked for free.
   cheap = 1,       // Checks that do not affect order (O(n) stays O(n)).
   expensive = 2,   // Checks that may affect order, but program still usable. 
   insane = 3       // Checks that make the program unusable. 
};


inline std::ostream& operator << ( std::ostream& out, checklevel lev )
{
   switch( lev )
   {
   case checklevel::forfree:
      out << "forfree"; return out;
   case checklevel::cheap:
      out << "cheap"; return out;
   case checklevel::expensive:
      out << "expensive"; return out;
   case checklevel::insane:
      out << "insane"; return out; 
   default:
      out << "undefined"; return out;
   }
}

#endif 

