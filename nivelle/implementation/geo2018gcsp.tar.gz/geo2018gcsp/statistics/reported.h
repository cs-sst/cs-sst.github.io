
#ifndef STATISTICS_REPORTED_INCLUDED
#define STATISTICS_REPORTED_INCLUDED   1


// The idea is to put this around a static variable, as in
// reported<size_t> counter = { 0, "counter" };
// Then the value will be reported when the variable is destroyed.

namespace statistics
{

   template< typename X >
   struct reported
   {
      X value;
      std::string name;

      reported( X value, const char* name )
         : value{ value },
           name{ std::string( name ) }
      { }


      ~reported( )
      {
         std::cout << "variable " << name;
         std::cout << " has final value " << value << "\n";
      }
   };
} 

#endif 

