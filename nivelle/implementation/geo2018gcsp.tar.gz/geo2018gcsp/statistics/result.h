


namespace statistics
{


   enum class result { file_error, parser_error, 
                       proven, model, time_out )

   double time; 
      // Time spent on the problem.                         
