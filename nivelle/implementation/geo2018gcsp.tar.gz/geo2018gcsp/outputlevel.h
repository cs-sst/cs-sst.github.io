
#ifndef OUTPUTLEVEL_INCLUDED
#define OUTPUTLEVEL_INCLUDED  1

Currenlty not used.

#include <iostream>

enum class outputlevel
{
   none = 0,            // No output. 
   entryexit = 1,       // Entries and exits of functions. 
   important = 2,       // Everything that appears important. 
   everything = 3       // Everything. 
};


inline std::ostream& operator << ( std::ostream& out, outputlevel lev )
{
   switch( lev )
   {
   case outputlevel::none:
      out << "none"; return out;
   case outputlevel::entryexit:
      out << "entryexit"; return out;
   case outputlevel::important:
      out << "important"; return out;
   case outputlevel::everything:
      out << "everything"; return out; 
   default:
      out << "undefined"; return out;
   }
}

#endif 

