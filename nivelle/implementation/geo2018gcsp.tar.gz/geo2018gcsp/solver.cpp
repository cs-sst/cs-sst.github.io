
#include <cstdlib>
#include <memory>

#include "statistics/distribution.h"
#include "statistics/timer.h"
#include "statistics/reporter.h"

#include <cstring>
#include <iostream>

#include "geometric/constraints/gcsp.h"
#include "geometric/constraints/subststack.h"
#include "geometric/constraints/lemma.h" 
#include "geometric/constraints/counters.h" 
#include "geometric/constraints/solve.h"
#include "geometric/constraints/standalone.h" 



int main( int nrargs, char* args [] )
{
   if( nrargs > 4 ) 
   {
      std::cerr << "too many parameters, maximum = 3\n"; 
      return 0;
   }

   bool cnf_only = false; 
      // If true, we translate to CNF only,
      // and don't run the solver.

   std::string inputfile;

   std::unique_ptr< std::ifstream > inputstream;

   int arg = 1;   // argument that we looking at.
 
   if( arg < nrargs )
   {
      if( strcmp( args[ arg ], "-cnf" ) == 0 || 
          strcmp( args[ arg ], "-CNF" ) == 0 ) 
      {
         cnf_only = true;
         ++ arg; 
      }
   }

   if( arg < nrargs )
   {
      inputfile = args[ arg ++ ];
      inputstream = std::move( std::unique_ptr< std::ifstream > 
         ( new std::ifstream{ inputfile })); 
      if( ! *inputstream )
      {
         std::cerr << "could not open inputfile " << inputfile << "\n";
         return 0;
      }
   }

   if( arg < nrargs )
   {
      std::cerr << "there are unprocessed parameters\n";
      std::cerr << "first = " << args [arg] << "\n";
      return 0;
   }

#if 0
   if( cnf_only )
      std::cout << "generating CNF only\n";

   std::cout << "inputfile  = " << inputfile << "\n";
#endif

   geometric::constraints::inputstream input{ 
      inputfile == "" ? &std::cin : inputstream. get( ),
      inputfile == "" ? "STDCIN" : inputfile };

   geometric::constraints::standalone( input, cnf_only ); 
   return 0;

}


