
// This is mostly useful for generation of error messages:

#ifndef TOSTRING_INCLUDED
#define TOSTRING_INCLUDED  1

#include <sstream>
#include <string>

template< typename T1 >
std::string tostring( const T1& t1 )
{
   std::ostringstream out;
   out << t1;
   return out. str( );
}

template< typename T1, typename T2 >
std::string tostring( const T1& t1, const T2& t2 )
{
   std::ostringstream out;
   out << t1 << t2;
   return out. str( );
}

template< typename T1, typename T2, typename T3 >
std::string tostring( const T1& t1, const T2& t2, const T3& t3 )
{
   std::ostringstream out;
   out << t1 << t2 << t3;
   return out. str( );
}

template< typename T1, typename T2, typename T3, typename T4 >
std::string tostring( const T1& t1, const T2& t2, const T3& t3, const T4& t4 )
{
   std::ostringstream out;
   out << t1 << t2 << t3 << t4;
   return out. str( );
}

#endif 

