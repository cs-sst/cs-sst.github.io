
#ifndef GEOMETRIC_VARIABLEMAP_INCLUDED
#define GEOMETRIC_VARIABLEMAP_INCLUDED 1

// A map from variables towards D.
// D must have a default constructor.
// If you don't like that, use std::optional.

#include "variable.h"
#include <vector>

namespace geometric
{

   template< typename D >
   struct variablemap 
   {
      std::vector< std::pair< variable, D>> data; 
         // Pairs, because we want our iterators to look like
         // map iterators. I don't think it will cost much in
         // efficiency. Using >> still feels a bit haram. 

      // const & at( size_t ) const; 

      // The following three functions are total:

      D& operator[]( variable v );
      const D& at( variable v ) const;
 
      const D& operator[]( variable v ) const { return at(v); } 

      bool indomain( variable v ) const { return v.x < data. size( ); }

      using iterator = 
         typename std::vector< std::pair< variable, D >> :: iterator;
      using const_iterator = 
         typename std::vector< std::pair< variable, D >> :: const_iterator;

      iterator begin( ) { return data. begin( ); }
      iterator end( ) { return data. end( ); }

      const_iterator cbegin( ) const { return data. cbegin( ); }
      const_iterator cend( ) const { return data. cend( ); }

      const_iterator begin( ) const { return data. begin( ); }
      const_iterator end( ) const { return data. end( ); }

      void clear( ) { data. clear( ); } 
   };

   template< typename D > 
   D& variablemap<D>::operator[]( variable v )
   {
      if( v.x >= data. size( ))
      {
         data. reserve( v.x + 1 );
         while( data. size( ) < v.x + 1 )  
            data. emplace_back( variable( data. size( )), D{} ); 
      }

      return data[ v.x ]. second; 
   }

   template< typename D >
   const D& variablemap<D> :: at( variable v ) const
   {
      if( indomain(v)) 
         return data[ v.x ]. second;
      else
      {
         static const D d;
         return d;
      }
   }

}

#endif

