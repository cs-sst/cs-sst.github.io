
// Written by Hans de Nivelle, November 2016.
// A newlemma is a lemma that is not yet
// entered into the lemmasystem.

#ifndef GEOMETRIC_CONSTRAINTS_NEWLEMMA_INCLUDED
#define GEOMETRIC_CONSTRAINTS_NEWLEMMA_INCLUDED  1

#include "lemma.h"

namespace geometric
{
namespace constraints 
{

   // A new lemma is a lemma together with the cost of obtaining it.

   struct newlemma
   {
      lemma lem;
      unsigned int cost;

      newlemma( lemma&& lem, unsigned int cost )
         : lem( std::move( lem )), cost( cost )
      { }

   };

   inline std::ostream& operator << ( std::ostream& out, const newlemma& n )
   {   
      out << n. lem << "   ( cost " << n. cost << " )";
      return out;
   }

}}

#endif

