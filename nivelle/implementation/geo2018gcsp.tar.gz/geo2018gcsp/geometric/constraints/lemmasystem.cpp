
// Written by Hans de Nivelle, December 2017.

#include <stdexcept>

#include "lemmasystem.h"
#include "resolution.h"
#include "../../checklevel.h"
#include "../../statistics/distribution.h"

namespace geometric
{
namespace constraints
{

   namespace
   {
      static constexpr checklevel checking = checklevel::forfree;
      static constexpr unsigned int outputlevel = 0;
   }


size_t lemmasystem::insert( const subststack< size_t > & theta,
                            size_t cost, lemma&& lem ) 
{
   if( outputlevel > 0 )
      std::cout << "Inserting " << lem << "\n";

   if( checking >= checklevel::insane && subsumes( lem ))
      throw std::runtime_error( "insert: inserting a subsumed lemma" ); 

   if( checking >= checklevel::expensive && istrue( theta, lem ))
      throw std::runtime_error( "insert: inserting a true lemma" );

   if( checking >= checklevel::expensive && !consistent( theta, lem ))
      throw std::runtime_error( "insert: inserting an inconsistent lemma" );

   size_t position = sys. size( );  // Position where lem will be put. 

   auto p = bestwatchable( theta, lem ); 

   watchings[ p -> v ]. emplace_back( position, p - lem. begin( ));

   sys. emplace_back( cost, std::move( lem ));
   return position; 
}


size_t
lemmasystem::findconflict( const subststack< size_t > & theta, size_t s )
{
   size_t bestconfl = nrlemmas( );

   if( s > theta. size( )) throw std::runtime_error( "out of range" );

   if( outputlevel >= 2 ) 
   {
      std::cout << "Entering findconflict with ";
      std::cout << theta << " / " << s << "\n";
   }

   while( s != theta. size( ))  
   {
      variable var = theta[s]. first;
      size_t val = theta[s]. second; 

      if( outputlevel >= 3 ) 
         std::cout << "trigger variable " << var << " := " << val << "\n";

      auto& ww = watchings[ var ];   // We're already not const anyway. 

      // Not a for loop, because we may delete *p: 

      auto p = ww. begin( );
      while( p != ww. end( ))
      {
         // We are enumerating lem/nr that contain variable var.

         size_t nr = p -> lem; 
         size_t w = p -> w; 
         const lemma& lem = sys[nr]. lem;

         if( !lem. contains( lem. begin( ) + w, val ))
         { 
            auto w1 = bestwatchable( theta, lem );
      
            // Failure to find one means: All variables are assigned,
            // and not consistent with theta.
 
            if( w1 == lem. end( ))
            {
               improveconflict( bestconfl, nr );
               ++ p; 
            }
            else
            {
               // We stop watching w and will start watching w1:

               std::swap( *p, ww. back( ));
               ww. pop_back( );

               watchings[ w1 -> v ]. emplace_back( nr, w1 - lem. begin( ) ); 
            }
         }
         else
            ++ p;
      }
      ++ s;
   }

   if( checking >= checklevel::expensive && 
       bestconfl < nrlemmas( ) &&
       consistent( theta, sys[ bestconfl ]. lem ))
   {
      std::cout << bestconfl << "\n";
      throw std::runtime_error( "findconflict returns consistent lemma" );
   }

   return bestconfl;
}


size_t
lemmasystem::findconflict( const subststack< size_t > & theta, size_t s ) const
{
   size_t bestconfl = nrlemmas( );

   if( s > theta. size( )) throw std::runtime_error( "out of range" );

   if( outputlevel >= 2 ) 
   {
      std::cout << "Entering findconflict(const) with ";
      std::cout << theta << " / " << s << "\n";
   }

   while( s != theta. size( ))  
   {
      variable var = theta[s]. first;
      size_t val = theta[s]. second; 

      if( outputlevel >= 3 ) 
         std::cout << "trigger variable " << var << " := " << val << "\n";

      const auto& ww = watchings[ var ]; 
      for( const auto& wa : ww ) 
      {
         const lemma& lem = sys[ wa. lem ]. lem;

         std::cout << "watched by lemma " << wa.lem << " / " << wa.w << "\n";

         if( !consistent( theta, lem ))
            improveconflict( bestconfl, wa. lem );
      }
      ++ s; 
   }

   if( checking >= checklevel::expensive && 
       bestconfl < nrlemmas( ) &&
       consistent( theta, sys[ bestconfl ]. lem ))
   {
      std::cout << bestconfl << "\n";
      throw std::runtime_error( "findconflict returns consistent lemma" );
   }

   return bestconfl;
}


bool 
lemmasystem::improveconflict( size_t& best, size_t nr ) const
{
   if( outputlevel >= 3 )
   {
      std::cout << "Improve conflict ";
      std::cout << best << " into " << nr << "?\n"; 
   }

   if( nr >= nrlemmas( )) 
      return false;

   if( best >= nrlemmas( ))
   {
      best = nr;
      return true;
   }

   if( sys[nr]. lem. betterthan( sys[best]. lem ))
   {
      best = nr; 
      return true;
   }

   return false; 
}


void 
lemmasystem::checkstate( const subststack< size_t > & theta ) const 
{
   size_t totalwatched = 0;

   for( const auto& w : watchings )
      for( const auto& p : w. second )
      {
         ++ totalwatched;

         auto it = sys[ p. lem ]. lem. begin( ) + p. w;
         auto val = theta. lookup( it -> v );
         if( val && ! sys[ p. lem ]. lem. contains( it, *val ))
         {
            std::cout << "Checkstate:\n";
            std::cout << "   " << p. lem << " : "; 
            std::cout << sys[ p. lem ]. lem << " / ";
            std::cout << ( sys[ p. lem ]. lem. begin( ) + p. w ) -> v;
            std::cout << "\n";
            std::cout << theta << "\n";
 
            throw std::runtime_error( "watched choice conflicts" );
         } 
      }

   if( totalwatched != nrlemmas( ))
      throw std::runtime_error( "total number of watchings does not fit" );
}


bool lemmasystem::subsumes( const lemma& lem ) const
{
   for( const auto& l : sys )
   {
      if( l. lem. subsumes( lem ))
         return true;
   }
   return false;
}


void lemmasystem::printstatistics( std::ostream& out ) const
{
   std::cout << "lemmasystem::printstatistics:\n";
   out << "There are " << nrlemmas( ) << " lemmas\n";

   {
      statistics::distribution distr{ 0.0, 200.0, 200 };
      for( size_t i = 0; i < nrlemmas( ); ++ i )
         distr. insert( sys[i]. lem. totalsize( ));
      out << "\n";
      out << "Distribution of totalsize of lemmas:\n"; 
      out << distr << "\n"; 
   }

   {
      statistics::distribution distr{ 0.0, 100.0, 100 };
      for( size_t i = 0; i < nrlemmas( ); ++ i )
         distr. insert( sys[i]. lem. nrvariables( ));
      out << "\n";
      out << "Distribution of number of variables in lemmas:\n";   
      out << distr << "\n";
   }

   {
      statistics::distribution distr{ 0.0, 100.0, 100 };
      for( size_t i = 0; i < nrlemmas( ); ++ i )
      {
         for( auto p = sys[i]. lem. begin( ); p != sys[i]. lem. end( ); ++ p )
         {
            size_t s =
                  sys[i]. lem. values_end(p) - sys[i]. lem. values_begin(p);

            distr. insert(s);
         }
      }

      out << "\n";
      out << "Distribution of number of values per variable:\n";
      out << distr << "\n";
   }

}


lemma::const_iterator 
lemmasystem::bestwatchable( const subststack< size_t > & theta, 
                            const lemma& lem )
{
   if( outputlevel >= 4 ) 
      std::cout << "finding watchable for " << lem << "\n";

   auto u = lem. end( );   
      // If we find an unassigned, we put it here.

   for( auto p = lem. begin( ); p != lem. end( ); ++ p )
   {
      auto val = theta. lookup( p -> v );
      if( !val )
         u = p;
      else
      {
         if( lem. contains( p, *val ))
            return p;
      }
   }

   return u;  // An unassigned, if there was one, otherwise
              // lem. end( ).
}


std::ostream& 
operator << ( std::ostream& out, const lemmasystem::annotatedlemma& a ) 
{
   out << "{ " << a. cost << ", " << a. nruses << "/" << a. lastuse << " }\n";
   out << "      " << a. lem << "\n";
   return out;
}


std::ostream& 
operator << ( std::ostream& out, const lemmasystem::watching watch )
{
   out << watch.lem << "/" << watch.w;
   return out;
}


std::ostream& operator << ( std::ostream& out, const lemmasystem& sys )
{
   out << "Lemma System:\n";

   for( size_t i = 0; i < sys. nrlemmas( ); ++ i )
   {
      out << i << " : " << sys. sys[i] << "\n";
   }
   out << "\n";

   out << "Watchings:\n";
   for( const auto& v: sys. watchings )
   {
      out << "   " << v. first << "   : {";
      for( auto p = v. second. begin( ); p != v. second. end( ); ++ p )
      {
         if( p != v. second. begin( ))
            out << ", ";
         else
            out << " ";
         out << *p;
      }
      out << " }\n";
   }

   return out;
}


}}



