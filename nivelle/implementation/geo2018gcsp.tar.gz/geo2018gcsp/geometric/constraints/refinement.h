
// A refinement is when some clause is replaced by a subclause.
// There are two possible ways in which this can happen:
// By guessing or by filtering.

#ifndef GEOMETRIC_CONSTRAINTS_REFINEMENT_INCLUDED
#define GEOMETRIC_CONSTRAINTS_REFINEMENT_INCLUDED  1

#include "gcsp.h"
#include "lemma.h"
#include "checked.h" 

namespace geometric
{
namespace constraints 
{

   struct refinement 
   {
      bool dec;            // True if we are a decision. 
      size_t cl;           // Number of clause that is being refined.

      gcsp::clause::state previous;  // State of cl before refinement.
      size_t newsize;                // So that we can check if we are last.
      size_t subst_restore;   

      refinement( bool dec, size_t cl, 
                  gcsp::clause::state previous,
                  size_t newsize, size_t subst_restore )
         : dec( dec ), 
           cl( cl ),
           previous( previous ),
           newsize( newsize ), 
           subst_restore( subst_restore ) 
      { }
     
      bool iscurrent( const gcsp& g ) const  
         { return g. clauses[ cl ]. current. size( ) == newsize; }

   };


   std::ostream& operator << ( std::ostream& , const refinement& ref );
   std::ostream& 
   operator << ( std::ostream& , const std::vector< refinement > & log ); 


}}

#endif

