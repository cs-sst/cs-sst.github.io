
#include "checked.h"

namespace geometric 
{
namespace constraints
{

   // Because order does not matter, hashing must be order independent.

   size_t 
   checked::hasher::operator( ) ( const path& pp ) const
   {
      size_t h = 0; 
      for( auto s : pp. visited )
      {
         h += s*s*s;
      }  

      return 1009 * h + pp. last;
   }


   bool 
   checked::equality::operator( ) ( const path& pp1, const path& pp2 ) const
   {  if( pp1. last != pp2. last )
         return false;
      if( pp1. visited. size( ) != pp2. visited. size( ))
         return false;
      for( auto s : pp1. visited )
      {
         if( nr_occurrences( s, pp1. visited ) !=
             nr_occurrences( s, pp2. visited ))
         {
            return false;
         }
      }
      return true;
   }


   std::ostream& operator << ( std::ostream& out, const checked::path& pp )
   {
      print( out, pp. visited );
      out << "/"; 
      out << pp. last;
      return out;
   }
   
   std::ostream& operator << ( std::ostream& out, const checked& c ) 
   {
      out << "checked[";
      for( auto p = c. map. begin( ); p != c. map. end( ); ++ p )
      {
         if( p != c. map. begin( ))
            out << ", ";
         else
            out << " ";
         out << *p; 
      }
      out << " ]";
      return out;
   }


}}


