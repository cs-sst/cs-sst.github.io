
// Written by Hans de Nivelle, December 2016.

#ifndef GEOMETRIC_CONSTRAINTS_COUNTERS_INCLUDED
#define GEOMETRIC_CONSTRAINTS_COUNTERS_INCLUDED  1

#include <iostream>

namespace geometric 
{
namespace constraints 
{
   // The main counters that you would like to know about a search tree:

   struct counters
   {
      long unsigned int conflicts;
      long unsigned int solutions;
      long unsigned int forwards;
      long unsigned int decisions;

      counters( ) 
         : conflicts{0},
           solutions{0},
           forwards{0},
           decisions{0}
      { }

      counters( long unsigned int conflicts,
                long unsigned int solutions,
                long unsigned int forwards,
                long unsigned int decisions )
      : conflicts{ conflicts },
        solutions{ solutions },
        forwards{ forwards },
        decisions{ decisions }
      { }

   };


   inline counters operator + ( const counters& c1, const counters& c2 )
   { return counters( c1. conflicts + c2. conflicts,
                      c1. solutions + c2. solutions,
                      c1. forwards +  c2. forwards,
                      c1. decisions + c2. decisions ); 
   }

   inline void operator += ( counters& c1, const counters& c2 )
   {
      c1. conflicts += c2. conflicts;
      c1. solutions += c2. solutions;
      c1. forwards  += c2. forwards;
      c1. decisions += c2. decisions;
   }

   inline std::ostream& operator << ( std::ostream& out, const counters& c )
   {
      out << "counters( conflicts = " << c. conflicts << ", ";
      out << "solutions = " << c. solutions << ", ";
      out << "forwards = " << c. forwards << ", ";
      out << "decisions = " << c. decisions << " )";
      return out;
   }

}}

#endif


