
#include "lemma.h"
#include "../../checklevel.h" 

namespace geometric
{
namespace constraints
{

   namespace
   {
      constexpr unsigned int outputlevel = 0;
   }


   lemma::lemma( const builder& b ) 
   {
      for( const auto& p : b )
      {
         if( p. second. size( ))
         {
            size_t i0 = values. size( ); 
            for( const size_t val : p. second )
               values. push_back( val );

            varmap. push_back( { p. first, i0, values. size( ) } ); 
         }
      } 
   } 


   bool lemma::contains( const_iterator p, size_t val ) const 
   {
      size_t lower = p -> r0;
      size_t upper = p -> r1;

      // Choice for 4 is arbitrary:

      while( upper - lower > 4 )
      {
         size_t middle = lower + ( upper - lower ) / 2;

         if( values[ middle ] <= val )
            lower = middle;
         else
            upper = middle;
      }
  
      // End with linear search:

      while( lower < upper )
      {
         if( values[ lower ] == val )
            return true;

         ++ lower;
      }

      return false;
   }


   
#if 0

   bool 
   geometric::constraints::lemma::implies( 
      const lemma& lem1, size_t i1,
      const lemma& lem2, size_t i2 )
   {
      // Every assignment in lem2[i2] must occur in lem1[i1]:

      for( size_t a2 =  lem2. substlets[i2]. a0;
                  a2 != lem2. substlets[i2]. a1;
                  ++ a2 )
      {
         bool found = false;

         for( size_t a1 =  lem1. substlets[i1]. a0;
                     a1 != lem1. substlets[i1]. a1 && !found;
                     ++ a1 )
         {
            if( lem1. assignments[a1]. var == lem2. assignments[a2]. var &&
                lem1. assignments[a1]. val == lem2. assignments[a2]. val )
            {
               found = true; 
            }
         }
         if( !found )
            return false; 
      }
      return true;
   }

#endif

   bool lemma::subsumes( const lemma& totalloser ) const
   {
      // std::cout << "subsumes " << *this << "    " << totalloser << " ?\n";

      if( values. size( ) > totalloser. values. size( ))
         return false;
            // We found a winner!

      // This is correct, because there exist no empty variable sets:

      if( varmap. size( ) > totalloser. varmap. size( ))
         return false;
            // We found a winner!

      for( auto p1 = begin( ); p1 != end( ); ++ p1 )
      {
         auto p2 = totalloser. find( p1 -> v );
         if( p2 == totalloser. end( ))
            return false;

         auto q2 = totalloser. values_begin( p2 );

         for( auto q1 = values_begin( p1 ); q1 != values_end( p1 ); ++ q1 )
         {
            while( q2 != totalloser. values_end( p2 ) && *q1 > *q2 ) 
               ++ q2;  

            if( q2 == totalloser. values_end( p2 ) || *q1 != *q2 )
               return false; 
 
            ++ q2;
         }
      }

      return true; 
   }


   bool lemma::betterthan( const lemma& totalloser ) const
   {
      // It seems that comparing nrvariables first is slightly worse
      // than comparing totalsize first. The difference is very small. 

      auto s1 = totalsize( );
      auto s2 = totalloser. totalsize( ); 

      if( s1 < s2 ) return true;
      if( s1 > s2 ) return false; 

      auto v1 = nrvariables( ); 
      auto v2 = totalloser. nrvariables( );

      if( v1 < v2 ) return true;
      if( v1 > v2 ) return false;

      return false;
   }


   lemma::builder
   lemma::make_builder( std::initializer_list<
             std::pair< variable, std::initializer_list< size_t >>> aa )
   {
      builder bb;
      for( const auto& p : aa )
      {
         // If p. second is empty, we ignore it: 

         if( p. second. size( ))
         {
            // If there already is a vi/Vi with variable
            // p. first, we merge. Otherwise, we create. 

            bb[ p. first ]. insert( p. second ); 
         }
      }
      return bb;
   }

 
   std::ostream& operator << ( std::ostream& out, const lemma& lem )
   {
      if( lem. nrvariables( ) == 0 ) 
      {
         out << "(empty)";
         return out;
      }
      else
      {
         for( auto p = lem. begin( ); p != lem. end( ); ++ p )
         {
            if( p != lem. begin( ))
               out << ", ";

            out << ( p -> v ) << "/";
            out << "{";
            for( auto q = lem. values_begin(p);
                      q != lem. values_end(p); 
                      ++ q ) 
            {
               if( q != lem. values_begin(p))
                  out << ",";
               out << *q;
            }
            out << "}";
         }
      }
      return out; 
   }


   bool consistent( const subststack< size_t > & theta, const lemma& lem )
   {

      if( false ) 
         std::cout << "consistent " << lem << "\n";

      for( auto p = lem. begin( ); p != lem. end( ); ++ p )
      {
         const auto* val = theta. lookup( p -> v ); 

         // If block. v does not occur in theta, it can be anything.
         // Therefore, the block is consistent. 

         if( !val || lem. contains( p, *val ))
            return true;
      }
      return false;
   }


   bool istrue( const subststack< size_t > & theta, const lemma& lem )
   {
      if( false )
      {
         std::cout << theta << "\n"; 
         std::cout << "istrue " << lem << " ?\n";
      }

      for( auto p = lem. begin( ); p != lem. end( ); ++ p )
      {
         const auto* val = theta. lookup( p -> v );
         if( val && lem. contains( p, *val ))
            return true;
      }
      return false;
   }

        
   lemma::const_iterator
   produces( const subststack< size_t > & theta, const lemma& lem )
   {
      if( outputlevel >= 4 ) 
      {
         std::cout << "forward " << lem << "\n";
         std::cout << theta << "\n";
      }

      auto u = lem. end( );   // The unassigned variable.
 
      for( auto c = lem. begin( ); c != lem. end( ); ++ c )
      {
         auto p = theta. lookup( c -> v );
         if( !p )
         {
            if( u != lem. end( ))
               return lem. end( );     // More than one unassigned variable.

            u = c;   // It's the first unassigned. 
         }
         else
         {
            if( lem. contains( c, *p ))
               return lem. end( );     // Lemma is true.
         }
      }

      return u; 
   } 
   
#if 0
   bool
   consistent( const lemma& lem, size_t i, const gcsp::clause& cl, size_t j )
   {
      // std::cout << "consistent " << lem << " / " << i << "\n";
      // std::cout << "           " << cl << " / " << j << "\n";

      for( size_t a = 0; a != lem. nrassignments( i ); ++ a )
      {
         for( size_t v = 0; v != cl. nrvars( ); ++ v )
         {
            auto av = lem. getassignment(i,a); 
            if( av. var == cl. var(v) && av. val != cl. value(v,j) )
            {
               return false;
            }
         }
      }  

      return true;
   }


   bool consistent( const gcsp::clause& cl, const lemma& lem, size_t i )
   {
      for( size_t c = cl. current. s0; c != cl. current. s1; ++ c )
      {
         if( consistent( lem, i, cl, c ))
            return true;
      }
      return false;
   }


   bool consistent( const gcsp::clause& cl, 
                    variable var, size_t val,
                    const lemma& lem, size_t i )
   {
      // std::cout << "consistent " << lem << "/" << i << "\n";
      // std::cout << cl << "\n";
      // std::cout << "( "<< var << " := " << val << " )\n";

      // First find var in cl:

      size_t v = 0;
      while( cl. var(v) != var )
         ++ v;

      // If var does not occur in cl, and we are not crashed yet,
      // then we do it now:

      if( v >= cl. nrvars( ))
         throw std::logic_error( "consistent: var does not occur in cl" ); 

      for( size_t c = cl. current. s0; c != cl. current. s1; ++ c )
      {
         if( cl. value( v, c ) == val )
         {
            if( consistent( lem, i, cl, c ))
               return true;
         }
      }

      return false;
   }

#endif


#if 0

   namespace
   {

      // Returns first i, s.t. lem/i is consistent with
      // theta. If we reach nrsubstlets( ), we start
      // at 0. 

      size_t firstconsistent( const lemma& lem, size_t i,
                              size_t& nrattempts,
                              const subststack< size_t > & theta )
      {
         if( nrattempts == 0 )
            throw std::runtime_error( "nrattempts == 0" );

         while( !consistent( theta, lem, i ))
         {
            ++ i; -- nrattempts;

            if( nrattempts == 0 )
               return 0;

            if( i == lem. nrsubstlets( ))
               i = 0;
         }

         return i;  
      }

      
      bool hasassignment( const gcsp::clause& cl,
                          size_t v, size_t val )
      {
         // std::cout << "hasassignment:\n";
         // std::cout << cl << "\n";
         // std::cout << "   " << cl. var(v) << " := " << val << " ?\n";

         for( size_t pos = cl. current. s0; pos != cl. current. s1; ++ pos )
         {
            if( cl. value( v, pos ) == val )
            {
               return true;
            }
         }

         return false;
      }


      // Return the first i such that lem/i agrees on variable
      // var with all candidates. We assume that candidates
      // are not empty, and they do contain the var. 
      // We believe that this is check is cheap, so that
      // it should be done separately. 
      // We may advance to an i for which lem/i does not 
      // contain var. In that case, the candidates agree 
      // trivially.

#endif
#if 0
   size_t bestconsistent( const lemma& lem, size_t i,
                          size_t& nrattempts, 
                          const subststack< size_t > & theta, 
                          const gcsp* g )
   {
      // std::cout << "bestconsistent " << lem << "\n";
      // std::cout << i << " " << nrattempts << "\n";
      // std::cout << theta << "\n";

      const bool wantsbest = false; 

      i = firstconsistent( lem, i, nrattempts, theta, g ); 
      if( nrattempts == 0 )
         return 0;      // Lemma is not consistent, result is irrelevant.

      if( !wantsbest )
         return i;
  
      size_t best = i; 

      while( true )
      {
         ++ i; -- nrattempts;
         if( nrattempts == 0 )
         {
            nrattempts = lem. nrsubstlets( ); 
               // because 0 would denote failure.
            return best; 
         }
      
         if( i == lem. nrsubstlets( ))
            i = 0;

         i = firstconsistent( lem, i, nrattempts, theta, g );

         if( nrattempts == 0 )
         {
            nrattempts = lem. nrsubstlets( ); 
            return best;
         }

         if( isbetterwatch( lem, theta, i, best ))
            best = i;
      }
   }


   bool match( subststack< size_t > & theta, const lemma& lem, size_t i )
   {
      for( size_t a = 0; a != lem. nrassignments(i); ++ a ) 
      {
         auto assign = lem. getassignment(i,a);  

         const auto* p = theta. lookup( assign. var );
         if( !p )
            theta. assign( assign. var, assign. val );
         else
         {
            if( *p != assign. val )
               return false;
         }
      }
      return true;
   }

#endif

}}


