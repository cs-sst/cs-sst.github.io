
#ifndef GEOMETRIC_CONSTRAINTS_CNF
#define GEOMETRIC_CONSTRAINTS_CNF  1

#include <iostream>
#include <vector>

#include "gcsp.h"

namespace geometric {
namespace constraints {

   struct cnf 
   {
      using clause = std::vector<int> ; 

      std::vector< clause > clauseset;

      cnf( ) { } 
      cnf( std::initializer_list< std::initializer_list< int >> init );

      int maxvar( ) const;
         // Absolute value of the biggest literal in the problem.

      size_t nrclauses( ) const { return clauseset. size( ); }

      void insert( const clause& cl )
         { clauseset. push_back( cl ); }

      void insert( clause&& cl )
         { clauseset. push_back( std::move(cl) ); }

   };

   std::ostream& operator << ( std::ostream& out, const cnf& c ); 
      // In DIMACS format, so that it can be input to SAT solver.

   cnf translate2cnf( const gcsp& g ); 

}}

#endif

