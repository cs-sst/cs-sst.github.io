
#ifndef GEOMETRIC_CONSTRAINTS_STANDALONE_INCLUDED
#define GEOMETRIC_CONSTRAINTS_STANDALONE_INCLUDED  1

#include <iostream>
#include <string>
#include "inputstream.h"

namespace geometric {
namespace constraints {

   void standalone( inputstream& input, bool cnf_only );
}}

#endif

