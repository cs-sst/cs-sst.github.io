
#ifndef GEOMETRIC_CONSTRAINTS_INPUTSTREAM_DECLARED 
#define GEOMETRIC_CONSTRAINTS_INPUTSTREAM_DECLARED  1

#include <string>
#include <stdexcept>
#include <istream>
#include <fstream>
#include <iostream>

// An inputstream adds counters (counting line and column) to an 
// istream, it allows for easy inspection of the next character.

namespace geometric {
namespace constraints 
{

   struct inputstream
   {
      std::istream* input; 
      const std::string name;

      unsigned int linenumber;
      unsigned int columnnumber;

      int nextchar;

      // inp must exist during life time of the inputstream.

      inputstream( std::istream* inp, const std::string& name )
         : input{ inp }, 
           name{ name },
           linenumber{1},
           columnnumber{0},
           nextchar{ input -> get( ) } 
      { 
         if( input -> fail( ))
            throw std::runtime_error( "could not open " + name ); 
      }

      bool eof( ) const { return input -> eof( ); }
      bool fail( ) const { return input -> fail( ); }

      void moveforward( );
        // Moveforward reads a new nextchar from the current 
        // inputfile. 

      inputstream( const inputstream& ) = delete; 
      void operator = ( const inputstream& ) = delete; 

      std::string inlineoffile( ) const;
         // Create the string 'in line L of file F'.
         // This is useful for error messages. 


      static bool startidentifier( char c );
      static bool inidentifier( char c );
      static bool isdigit( char c );
      static bool iswhitespace( char c );

      static 
      bool equalwithoutcase( const std::string& s1, const char* s2 );
          // equalwithoutcase( "Equal", "eQuAl" );

      void skipwhitespace( );       
      void readcomment( );
      std::string readidentifier( );
      size_t readunsigned( );

   };


   struct syntax_error : public std::runtime_error
   {
      syntax_error( const std::string& error )
         : std::runtime_error( error. c_str( ))
      { }
   };
   
}} 

#endif


