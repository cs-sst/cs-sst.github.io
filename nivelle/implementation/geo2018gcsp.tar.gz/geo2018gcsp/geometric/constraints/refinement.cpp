
// Part of Geo III, written by Hans de Nivelle, June 2016.

#include "refinement.h"
#include "resolution.h"

namespace geometric 
{
namespace constraints
{



   std::ostream& operator << ( std::ostream& out, const refinement& ref )
   {
      if( ref. dec )
         out << "Decision for ";
      else
         out << "Refinement of ";

      out << "clause " << ref. cl << " from " << ref. previous << " and ";
      out << "substitution having size " << ref. subst_restore;
      return out;
   }


   std::ostream& operator << ( std::ostream& out, 
                               const std::vector< refinement > & log )
   {
      out << "Refinement Stack:\n";
      for( size_t i = 0; i < log. size( ); ++ i )
      {
         out << i << " : " << log[i] << "\n";
      }
      out << "\n";
      return out;
   }


}}


