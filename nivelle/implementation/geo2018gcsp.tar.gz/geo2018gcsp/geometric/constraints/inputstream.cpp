
#include "inputstream.h" 
#include <sstream>

namespace geometric {
namespace constraints 
{

   std::string inputstream::inlineoffile( ) const
   {
      std::ostringstream ss;
      ss << "in line " << linenumber << " of file " << name;
      ss << " at position " << columnnumber; 
      return ss. str( );
   }


   void inputstream::moveforward( ) 
   {
      if( eof( ))
      {
         throw std::logic_error( 
                       "read beyond end of file " + inlineoffile( ));
      }

      nextchar = input -> get( );
      ++ columnnumber;

      if( nextchar == '\n' )
      {
         ++ linenumber;
         columnnumber = 0;
      }

      if( input -> bad( ))
         throw std::runtime_error( "could not read input " + inlineoffile( ));
   }


   // Character classifiers:

   bool inputstream::startidentifier( char c )
   {
      if( c >= 'a' && c <= 'z' ) return true;
      if( c >= 'A' && c <= 'Z' ) return true;
      if( c == '_' ) return true;
      return false;
   }

   bool inputstream::inidentifier( char c )
   {
      if( c >= 'a' && c <= 'z' ) return true;
      if( c >= 'A' && c <= 'Z' ) return true;
      if( c >= '0' && c <= '9' ) return true;
      if( c == '_' ) return true;
      return false;
   }

   bool inputstream::isdigit( char c )
   {
      if( c >= '0' && c <= '9' ) return true;
      return false;
   }

   bool inputstream::iswhitespace( char c ) 
   {
      if( c == ' ' ) return true;
      if( c == '\t' ) return true; 
      if( c == '\n' ) return true;
      if( c == 0x0D ) return true;
      return false;
   }


   bool 
   inputstream::equalwithoutcase( const std::string& s1, const char* s2 )
   {
      auto p1 = s1. begin( );
      auto p2 = s1. end( );

      while( p1 != p2 && *s2 )
      {
         if( tolower( *p1 ) != tolower( *s2 ))
            return false;
         ++ p1;
         ++ s2;
      }

      if( p1 != p2 || *s2 ) return false;
         // One did not reach the end.

      return true;
   }

   void inputstream::skipwhitespace( )
   {
      while( !eof( ) && iswhitespace( nextchar ))
         moveforward( );
   }


   void inputstream::readcomment( )
   {
      if( eof( ) || ( nextchar != 'c' && nextchar != 'C' ) )
      {
         throw syntax_error( "readcomment: Did not find starting c "
                                  + inlineoffile( ));
      }

      while( !eof( ) && nextchar != '\n' )
      {
         moveforward( ); 
      }

      if( eof( ))  
      {
         throw syntax_error( "unexpected end-of-file in //-comment " +
                                   inlineoffile( ));
      }

      moveforward( );
   }


   std::string inputstream::readidentifier( )
   {
      std::string id; 

      if( eof( ) || !startidentifier( nextchar ))
      {
         throw syntax_error( 
            std::string( "readidentifier: identifier cannot start with " ) +
                   (char) nextchar + " " + inlineoffile( ));
      }

      id. push_back( nextchar );
      moveforward( );

      while( !eof( ) && inidentifier( nextchar ))
      {
         id. push_back( nextchar );
         moveforward( );
      }

      return id;
   }

 
   size_t inputstream::readunsigned( )
   {
      size_t val = 0;
      
      if( eof( ) || !isdigit( nextchar ))
      {
         throw syntax_error(
            std::string( "readunsigned: unsigned cannot start with " ) +
                   (char) nextchar + " " + inlineoffile( ));
      }

      while( !eof( ) && isdigit( nextchar ))
      {
         unsigned int x = nextchar - '0';
         if( x >= 10 )
            throw syntax_error( "x >= 10 cannot happen" );

         val = 10 * val + x;
        
         if( val >= 10000000000000 )
            throw syntax_error( "number is getting too big " + inlineoffile( ));
 
         moveforward( );  
      }

      return val;
   }
 
}} 



