
// Written by Hans de Nivelle, April 2016.

// Preprocessor contains the essential preprocessor. It does the following:
// Check for blockings that contain no variables. Return false if there is one.
// Check for substlets that imply a blocking. Remove these from the 
// clauses. If this results in an empty clause, or there is a clause
// that was already empty, then return false.

// this is complete trash that needs to be rewritten !

#ifndef GEOMETRIC_CONSTRAINTS_PREPROCESSOR_INCLUDED
#define GEOMETRIC_CONSTRAINTS_PREPROCESSOR_INCLUDED  1

#include <vector>
#include <iostream>

#include "subststack.h"
#include "gcsp.h"
#include "refinement.h"

namespace geometric 
{
namespace constraints 
{

   std::vector< refinement > 
   allclauses( const gcsp& g, const subststack< size_t > & theta );
      // Create a stack that states that nothing happened to any
      // of the clauses. It is used to trigger the preprocessor on each
      // clause.


   bool hassolution( subststack< size_t > & theta,
                     const gcsp& g, size_t cl, size_t i,
                     const std::vector< size_t > & cl_rest );
      // True if cl/i + cl_rest has a solution.
      // The substitution is extended and always restored.
      // We assume that cl/i is consistent with theta.

   // Note that preprocessing is essential for correctness.
   // We return false if we discover that the problem has no solution.
   // The preprocessor does not clear the substitution in advance, 
   // but it extends the substitution whenever it obtains a clause whose
   // assignments to a variable are in agreement. 
   // 
   // S = 0 means the minimal preprocessing. This means:
   //       If all substlets in a clause agree on an assignment,
   //       this assignment is present in the substitution.
   //       If a substlet conflicts with the substitution, this 
   //       substlet is not present in the clause.
   //       If a substlet together with the substitution implies a blocking,
   //       this substlet is not present in the clause.
   //       The substitution does not imply a blocking, and no clause
   //       is empty.           
   // S = 1 means that each clause is checked against each other clause
   //       that it shares a variable with.
   // S = 2 means that each clause is checked against each pair of clauses
   //       that it shares variables with. 
   // S = 3 etc.

   bool preprocessor( gcsp& g, subststack< size_t > & theta, size_t S );

}}

#endif

