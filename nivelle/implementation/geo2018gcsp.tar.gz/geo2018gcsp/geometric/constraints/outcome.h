
// Written by Hans de Nivelle, November 2016.

#ifndef GEOMETRIC_CONSTRAINTS_OUTCOME_INCLUDED
#define GEOMETRIC_CONSTRAINTS_OUTCOME_INCLUDED  1

#include <memory>
#include "lemmasystem.h"
#include "newlemma.h"

namespace geometric
{
namespace constraints 
{

   // An outcome (of matching) is either
   //    no lemma,
   //    a reused (existing) lemma,
   //    a new lemma.


   struct outcome
   {
      enum class type { nolemma, reusedlemma, newlemma };

      type t; 
      std::unique_ptr< newlemma > created; 
         // The new lemma, and its derivation cost, if we are new. 

      size_t index;
         // A reused lemma, and its index in lemmasystem.

      outcome( ) 
         : t{ type::nolemma }, index{0} 
      { }

      outcome( size_t index )
         : t{ type::reusedlemma }, index{ index }
      { }


      outcome( newlemma&& lem ) 
         : t( type::newlemma ), 
           created( new newlemma( std::move(lem) )),
           index(0)
      { }
 
      outcome( const outcome& ) = delete;
      outcome( outcome&& ) noexcept = default; 
      void operator = ( const outcome& ) = delete;
      outcome& operator = ( outcome&& ) = default;

      operator bool( ) const { return t != type::nolemma; }
         // True if we have a lemma.

      const lemma& getlemma( const lemmasystem& sys ) const 
         {
            if( t == type::nolemma ) throw std::runtime_error( "no lemma" );
            if( t == type::reusedlemma ) return sys[ index ];
            return created -> lem;
         }

      newlemma&& getnewlemma( ) &&
      {
         if( t != type::newlemma ) 
            throw std::runtime_error( "getnewlemma( ): there is no new lemma" );
         return std::move( *created );
      }
 
      unsigned int getcost( ) const
         {
            if( t == type::nolemma )
               throw std::runtime_error( "no cost" );
            if( t == type::reusedlemma )
               return 0;
            return ( created -> cost );
         }


      void check_learn( lemmasystem& sys, 
                  const subststack< size_t > & theta, 
                  unsigned int maxcost );
         // If we have a new lemma and it has become too costly, 
         // we insert our lemma into sys. After that, we become a 
         // reused lemma. 
       
   };

   std::ostream& operator << ( std::ostream& out, const outcome& res );

}}

#endif

