
#include "standalone.h"

#include "gcsp.h"
#include "preprocessor.h"
#include "solve.h"
#include "cnf.h"

namespace geometric {
namespace constraints {

void standalone( inputstream& input, bool cnf_only )
{
   try
   {
      gcsp g = gcsp::read( input );

      const size_t S = 2;

      subststack< size_t > theta;

      if( !preprocessor( g, theta, S ))
      {
         if( cnf_only )
         {
            // If the problem gets rejected by the preprocessor, it
            // is trivially unsatisfiable. Since we have to create
            // a SAT-translation, we output a trivial, non-satisfiable
            // problem:

            std::cout << "c problem is trivially unsatisfiable\n";
            std::cout << "p cnf 1 2\n";
            std::cout << "1 0\n";
            std::cout << "-1 0\n";
         }
         else
         {
            std::cout << "UNSAT\n";
         }
         return;
      }

      g. set_initials( );
      g. hard_commit( );

      if( cnf_only )
      {
         auto prop = translate2cnf(g);
         std::cout << "\n";
         std::cout << prop << "\n\n";
         return;
      }

      long unsigned int nr = solve( g, theta );

      if( nr )
      {
         std::cout << "SAT\n";
         std::cout << "Solution:   ";
         std::cout << theta. size( ) << "  ";
         for( size_t i = 0; i < theta. size( ); ++ i )
         {
            std::cout << theta[i]. first. getindex( ) << "  ";
            std::cout << theta[i]. second << "  ";
         }
         std::cout << "\n";
      }
      else
         std::cout << "UNSAT\n"; 
   }
   catch( const syntax_error& err )
   {
      std::cout << "syntax error: " << err. what( ) << "\n";
   }
   catch( const std::runtime_error& err )
   {
      std::cout << "runtime error: " << err. what( ) << "\n";
   }
}


}}


