
// A lemma has form v1/V1 ... vn/Vn, where
// each vi is a variable, and each Vi is a set of values.
// 
// There must be no identical Vi,Vj, because they can be merged.
// There must be no empty Vi, because they can be deleted.
// The Vi must be sorted in increasing order.
// The constructor automatically takes care of these invariants. 

#ifndef GEOMETRIC_CONSTRAINTS_LEMMA_INCLUDED
#define GEOMETRIC_CONSTRAINTS_LEMMA_INCLUDED  1

#include <vector>
#include <iostream>

#include "gcsp.h"
#include "subststack.h" 

#include <set>
#include <unordered_map>

namespace geometric 
{
namespace constraints 
{

   class lemma
   {

      std::vector< size_t > values; 

      // A lemma is a finite set of choices. A choice has form v/V. 
      // They are stored as pairs( v, ( i0, i1 )), where [ i0, i1 ) is an 
      // interval in values. We assume that values is sorted for each
      // range of values. 

   public: 
      struct varvalues
      {
         variable v; 
         size_t r0;    
         size_t r1; 

         varvalues( variable v, size_t r0, size_t r1 )
            : v(v), r0(r0), r1(r1)
         { }

         size_t nrvalues( ) const { return r1 - r0; }
      };

   private: 
      std::vector< varvalues > varmap; 
         // Maps variables to the valueranges containing their values. We 
         // could have used a map type instead. 
     
   public:  
      // We use ordered sets (instead of unordered), because it is possibly 
      // convenient during rewatching to have everything ordered:

      using builder = 
         std::unordered_map< variable, std::set< size_t >,
                             variable::hash, variable::equal_to > ;

      lemma( const builder& b );

      lemma( std::initializer_list<
                 std::pair< variable, std::initializer_list< size_t >>> aa )
         :lemma( make_builder(aa)) 
      { } 

      lemma( lemma&& ) noexcept = default;
      lemma( const lemma& ) = delete;

      using const_iterator = std::vector< varvalues > :: const_iterator; 

      const_iterator begin( ) const { return varmap. begin( ); }
      const_iterator end( ) const { return varmap. end( ); }
      size_t nrvariables( ) const { return varmap. size( ); }

      const_iterator find( variable v ) const
      { 
         const_iterator p = varmap. begin( );
         while( p != varmap. end( ) && ( p -> v ) != v )
            ++ p;
         return p;    // end( ) if variable v was not found. 
      }

      bool hasindomain( variable v ) const
      {
         for( const auto& m : varmap )
            if( m.v == v ) return true;
         return false;
      }
 
      size_t totalsize( ) const { return values. size( ); }

      using value_iterator = std::vector< size_t > :: const_iterator;

      value_iterator values_begin( const_iterator p ) const
         { return values. begin( ) + ( p -> r0 ); } 

      value_iterator values_end( const_iterator p ) const 
         { return values. begin( ) + ( p -> r1 ); }

      bool contains( const_iterator p, size_t val ) const;
         // True if the val is among the possible values. 

      bool subsumes( const lemma& totalloser ) const;
         // True if we subsume that other lemma.

      bool betterthan( const lemma& totalloser ) const;
         // True if we seem to be a better lemma than that sad 
         // loser over there. (We have less variables and less choices.)

   private:
      builder 
      make_builder( 
            std::initializer_list<
            std::pair< variable, std::initializer_list< size_t >>> aa );

   };

   std::ostream& operator << ( std::ostream& out, const lemma& lem );


   inline std::ostream& 
   operator << ( std::ostream& out, const lemma::varvalues v )
   {
      out << v. v << "/[ " << v.r0 << " .. " << v.r1 << " )";
      return out;
   }

   bool consistent( const subststack< size_t > & theta, const lemma& lem );
      // True if theta and lem are consistent.

   bool istrue( const subststack< size_t > & theta, const lemma& lem );
      // True if theta makes lem true. The function cannot be called 'true',
      // because it is a reserved word. 

   lemma::const_iterator 
   produces( const subststack< size_t > & theta, const lemma& lem );
      // If lem has exactly one unassigned variable, 
      // and the other variables conflict theta, return the 
      // iterator belonging to this unassigned variable. 
      // Return end( ) otherwise. 
      // This method is for debugging only, because it is not efficient to
      // look for inconsistent and forward lemmas separately. 

}}


#endif


