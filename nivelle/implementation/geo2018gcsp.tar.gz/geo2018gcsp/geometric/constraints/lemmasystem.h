
// Written by Hans de Nivelle, January 2017.
// Rewritten October/November 2017 for the improved algorithms.

#ifndef GEOMETRIC_CONSTRAINTS_LEMMASYSTEM_INCLUDED
#define GEOMETRIC_CONSTRAINTS_LEMMASYSTEM_INCLUDED  1

#include <vector>

#include "lemma.h"

namespace geometric 
{
namespace constraints 
{

   class lemmasystem
   {

      struct annotatedlemma
      {
         size_t cost;      // Cost of derivation of lem. 
         size_t nruses;    // How often it was used.
         size_t lastuse;   // Only meaningful if nruses > 0.

         lemma lem;

         annotatedlemma( size_t cost, lemma&& lem )
            : cost{ cost },
              nruses{0}, lastuse{0},
              lem{ std::move( lem ) }
         { }

      };


      struct watching 
      {
         size_t lem;
         size_t w;      // offset of watched variable.

         watching( size_t lem, size_t w )
            : lem{ lem },
              w{ w }
         { }
      };


   private: 
      std::vector< annotatedlemma > sys;

      variablemap< std::vector< watching >> watchings;
         // A map from variables to mappings from lemma numbers to
         // watchings involving the variable. 

   public: 
      lemmasystem( ) { } 

      // There must exist an unassigned variable in lem.
      // We watch one unassigned variable, and ignore the rest.

      size_t insert( const subststack< size_t > & theta, size_t cost, 
                     lemma&& lem );

      // find conflict involving variable v. Return size if there is none.
      // This may involve changing watchings.

      size_t findconflict( const subststack< size_t > & theta, size_t s );
      size_t findconflict( const subststack< size_t > & theta, size_t s ) const;
         // The first version rearranges watchings, which is needed if one
         // wants to find more conflicts later. 

      size_t nrlemmas( ) const { return sys. size( ); }

      const lemma& operator [] ( const size_t i ) const 
         { return sys[i]. lem; }

      void clear( ) { sys. clear( ); watchings. clear( ); } 

      void checkstate( const subststack< size_t > & theta ) const;
         // Check that no watched substlet conflicts with theta or g, 
         // that for every lemma there is a watched substlet, and
         // that watched substlets occur in the lemma. 
         // Print an error if something is wrong, and throw an exception. 
         // This function is expensive. It is for debugging only.

      bool subsumes( const lemma& lem ) const;  
         // True if one of our lemmas subsumes lem. 

      void printstatistics( std::ostream& out ) const;
         // Print statistics about the lemmas, and about the
         // watchings.

      static lemma::const_iterator 
      bestwatchable( const subststack< size_t > & theta, const lemma& lem );
         // Watchable is either unassigned, or true in theta. 
  
      void registeruse( size_t i )
      {
         sys[i]. lastuse = sys. size( );
         ++ sys[i]. nruses;
      }

   private:
      bool improveconflict( size_t& best, size_t nr ) const;

   public: 
      friend 
      std::ostream& operator << ( std::ostream& , const lemmasystem& ); 

      friend
      std::ostream& operator << ( std::ostream& , const annotatedlemma& ); 

      friend
      std::ostream& operator << ( std::ostream& , watching ); 
   };

   std::ostream& 
   operator << ( std::ostream& , const lemmasystem::annotatedlemma& ); 

   std::ostream& operator << ( std::ostream& , lemmasystem::watching );

   std::ostream& operator << ( std::ostream& out, const lemmasystem& sys );

}}

#endif


