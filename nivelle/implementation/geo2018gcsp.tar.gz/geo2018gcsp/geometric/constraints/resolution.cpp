
// Written by Hans de Nivelle, April/June 2016.

#include <list>
#include "resolution.h"
#include "../../checklevel.h"

namespace geometric
{
namespace constraints
{

   namespace
   {
      static constexpr checklevel checking = checklevel::forfree;
      static unsigned int constexpr outputlevel = 0;
   }


   namespace
   {

      // Count the number of variables that occur in the domain
      // of bl, but not in the domain of one the clauses in cover.

      size_t count_missing( const std::vector< const gcsp::clause* > & cover,
                            const gcsp::clause& bl )
      { 
         size_t nr = 0;

         for( size_t i = 0; i < bl. nrvars( ); ++ i )
         {
            variable v = bl. var(i);
         
            bool found = false;
            for( auto p = cover. begin( ); 
                 p != cover. end( ) && !found; ++ p )
            {
               if( (*p) -> indomain(v) )
                  found = true;
            }

            if( !found )
               ++ nr;
         }
         return nr;
      }
   }



   lemma sigma_resolvent( const gcsp& g, const gcsp::clause& bl, size_t j )
   {
      lemma::builder resolvent;

      if( outputlevel >= 2 )
      {
         std::cout << "creating sigma-resolvent for ";
         std::cout << bl << " / " << j << "\n\n";
      }

      // For every variable in bl, we find a clause containing it.
   
      for( size_t i = 0; i < bl. nrvars( ); ++ i )
      {
         variable v = bl. var(i);
         size_t x = bl. value( i, j );

         const gcsp::clause& cl = g. clauses[ *g. findclauses(v). begin( ) ];
            // findclauses(v) cannot be empty, because every variable
            // that occurs in a blocking, must occur in a clause.

         // Find the position of v in cl. 

         size_t vincl = 0;                   // place of 'v in cl'.
         while( cl. var( vincl ) != v )
            ++ vincl; 

         // Insert assignments to v that are different from x into
         // resolvent[v]: 

         std::set< size_t > & values = resolvent[v]; 
      
         for( size_t ccc = cl. initial. s0; ccc < cl. initial. s1; ++ ccc ) 
         {
            if( cl. value( vincl, ccc ) != x ) 
               values. insert( cl. value( vincl, ccc )); 
         }
      }

#if 0
      if( checking >= checklevel::cheap && consistent( theta, result ))
      {
         throw std::runtime_error( "sigma-resolution created a consistent lemma" );
      }
#endif

      return resolvent;
   }   


   bool sharedvarsconflict( const gcsp::clause& cl, size_t j, const lemma& lem )
   {
      for( auto p = lem. begin( ); p != lem. end( ); ++ p )
      {
         size_t v = 0;  
         while( v < cl. nrvars( ) && cl. var(v) != ( p -> v ))
            ++ v;
 
         if( v < cl. nrvars( ))
         {
            size_t x = cl. value( v, j );
            if( lem. contains( p, x ))
               return false;
         }
      }
      return true;
   } 

   
   void addnotshared( lemma::builder& res,
                      const gcsp::clause& cl, 
                      const lemma& lem )
   {
      if( outputlevel >= 3 )
      {
         std::cout << "Adding the nonshared variables from ";
         std::cout << lem << "\n";
         std::cout << " with clause " << cl << "\n";
      }

      for( auto p = lem. begin( ); p != lem. end( ); ++ p )
      {
         auto& valueset = res[ p -> v ]; 
            // The values for ( p -> v ) in the builder.

         if( !cl. indomain( p -> v )) 
         { 
            for( auto x = lem. values_begin(p); x != lem. values_end(p); ++ x )
               valueset. insert( *x );
         }
      }
   }


#if 1
 
   // Better version:

   bool addprojection( lemma::builder& res,
                       const gcsp::clause& cl, size_t j,
                       const subststack< size_t > & theta )
   { 
      if( outputlevel >= 3 )
      {
         std::cout << "Adding projection for choice " << j << "\n";
      }

      for( size_t v = 0; v != cl. nrvars( ); ++ v )
      {
         auto var = cl. var(v);
         size_t val = cl. value( v, j ); 

         auto p = theta. lookup( var );
         if( p && *p != val )
         {
            res[var]. insert(val);
            if( outputlevel >= 3 ) 
               std::cout << "chose " << var << "/" << val << "\n";
            return true;  
         }
      }
      return false;
   }

#else

   // This one is worse, even though it seems better in theory. 

   bool addprojection( lemma::builder& res,
                       const gcsp::clause& cl, size_t j,
                       const subststack< size_t > & theta )
   { 
      if( outputlevel >= 3 )
      {
         std::cout << "Adding projection for choice " << j << "\n";
      }

      size_t bestproj = cl. nrvars( );
      size_t bestposition = theta. size( );  // We prefer oldest. 

      for( size_t v = 0; v != cl. nrvars( ); ++ v )
      {
         variable var = cl. var(v);
         size_t val = cl. value( v, j );

         auto p = theta. lookup( var );
         if( p && *p != val )
         {
            // If var / val occurs in result, we reuse it. 

            if( res[ var ]. count( val ))
            {
               if( outputlevel >= 3 ) 
                  std::cout << "reusing " << var << "/" << val << "\n";
               return true;
            }   

            auto pos = theta. position( var );
            if( pos < bestposition ) 
            {
               if( outputlevel >= 4 )
               { 
                  std::cout << " considering " << var << "/" << val;
                  std::cout << " [ " << pos << "] ";
               }

               bestproj = v; 
               bestposition = pos;
            }
         }
      }

      if( bestproj != cl. nrvars( ))
      {
         variable var = cl. var( bestproj );
         size_t val = cl. value( bestproj, j ); 

         if( outputlevel >= 3 ) 
            std::cout << "projected " << var << "/" << val << "\n";

         res[ var ]. insert( val ); 
         return true; 
      } 
      else
         return false;         
   }

#endif 


   std::vector< newlemma > :: const_iterator 
   findconflict( const subststack< size_t > & theta,
                 const std::vector< newlemma > & conflset ) 
   {
      if( outputlevel >= 3 )
      {
         std::cout << "Find Conflict:\n";
         std::cout << theta << "\n";
         std::cout << "Conflict set:\n";
         for( const auto& c : conflset )
            std::cout << "      " << c << "\n";
         std::cout << "\n";
      }   

      auto first = conflset. begin( );
      while( first != conflset. end( ) && consistent( theta, first -> lem ))
         ++ first;

      if( first == conflset. end( ))
         return first;

      // We found one conflict, we try to improve it:

      auto best = first;
      for( auto p = first; p != conflset. end( ); ++ p ) 
      {
         if( p -> lem. betterthan( best -> lem ) && 
             !consistent( theta, p -> lem ))
         {
            best = p;
         }
      }
      return best;
   }


   newlemma resolvent( const gcsp::clause& cl,
                       subststack< size_t > & theta,
                       const gcsp& g,
		       lemmasystem& sys,
                       const std::vector< newlemma > & subconfl )
   {
      if( outputlevel >= 1 )
      {
         static long unsigned int counter = 0;

         std::cout << "\n";
         std::cout << "Constructing Resolvent " << counter++ << ":\n";

         std::cout << "Main Clause: " << cl << "\n";
         cl. printvertically( std::cout );
         std::cout << "\n";

         if( subconfl. size( ))
         {
            std::cout << "Subconflicts:\n"; 
            for( const auto& c : subconfl )
            {
               std::cout << "   " << c << "\n"; 
            }
            std::cout << "\n";
         }

         {
            // Print the instantiations of the variables in cl:

            std::cout << "Theta:  "; 
            for( size_t i = 0; i != cl. nrvars( ); ++ i )
            {
               variable v = cl. var(i); 
               auto p = theta. lookup(v); 
               if(i) std::cout << ", ";
               std::cout << v << " := ";
               if( p ) std::cout << *p;
               else
                  std::cout << "(unassigned)";
            }
            std::cout << "\n\n";
         }
 
      }

      if( checking >= checklevel::expensive )
      {

         if( g. impliesblocked( theta, 0 ))
            throw std::runtime_error( "theta implies a blocking" );

         if( findconflict( theta, subconfl ) != subconfl. end( ))
            throw std::runtime_error( "theta implies a sub conflict" );
      }

      // This check is very costly:

      if( checking >= checklevel::insane )
         sys. checkstate( theta ); 
 
      lemma::builder result;

      std::list< lemma > sigma;
         // If have to create any sigma-resolvents, we put them here.
         // It cannot be a vector, because we want to create pointers
         // to them. 
      
      // For each j in initial, the selected conflict with
      // its cost:

      std::unordered_map< size_t, std::pair< const lemma*, unsigned int >> 
         selections; 

      // We go through all choices cl/j, and for those that are consistent, 
      // we produce a conflict. 

      for( size_t j = cl. initial. s0; j != cl. initial. s1; ++ j )
      {
         if( consistent( theta, cl, j )) 
         {
            size_t s = theta. size( );
            match( theta, cl, j );

            if( s == theta. size( ))
               throw std::runtime_error( "resolve: main clause is true" );

            const lemma* best = nullptr;
            unsigned int cost_of_best = 0;

            {
               size_t ll = sys. findconflict( theta, s );
               if( ll < sys. nrlemmas( ))
               {
                  sys. registeruse( ll ); // We are not totally sure. 
                  best = & sys[ ll ];  // cost remains 0.
               }
            }

            {
               auto p = findconflict( theta, subconfl );
               if( p != subconfl. end( ))
               {
                  if( !best ||
                      ( p -> lem ). betterthan( *best ))
                  {
                     best = & ( p -> lem );
                     cost_of_best = ( p -> cost );
                  }
               }
            }

            {
               auto bl = g. getblocked( theta, s );
               if( bl. first != g. blockings. size( ))
               {
                  sigma. push_back(
                     sigma_resolvent( g, g. blockings[ bl. first ],
                                      bl. second ));

                  if( !best ||
                      sigma. back( ). betterthan( *best ))
                  {
                     best = & sigma. back( );
                     cost_of_best = 1;
                  }
               }
            }

            if( !best )
            {
               std::cout << theta << "\n";
               std::cout << cl << " / " << j << "\n";
               throw std::runtime_error( "failed to find a conflict lemma" );
            }

            selections. emplace( j, 
                 std::pair<const lemma*,unsigned int> ( best, cost_of_best ));

            theta. restore(s); 
         }
      }

      if( outputlevel >= 2 && selections. size( )) 
      {
         std::cout << "Selections:\n";
         for( const auto& sel : selections ) 
         {
            std::cout << "   " << sel. first << " --> ";
            std::cout << *sel. second. first << " / ";
            std::cout << sel. second. second << "\n";
         }
      }

#if 0
      // This is not worth the effort, and probably should be 
      // deleted again.

      for( auto p = selections. begin( ); p != selections. end( ); ++ p )
      {
         for( auto q = selections. begin( ); q != selections. end( ); ++ q )
         { 
            if( p != q )
            {
               if( sharedvarsconflict( cl, p -> first,
                                           *( q -> second. first )) &&
                   ( p -> second. first != q -> second. first ) &&
                   q -> second. first -> betterthan(
                            *( p -> second. first )))
               {
                  std::cout << "---------------------------\n"; 
                  std::cout << ( p -> first ) << " ---> ";
                  std::cout << * ( p -> second. first ) << "\n";

                  std::cout << "replaces by used\n";
                  std::cout << ( q -> first ) << " ---> ";
                  std::cout <<  * ( q -> second. first ) << "\n"; 

                  // p -> second. first = q -> second. first;  
                  throw std::runtime_error( "improvement is possible" ); 
               }
            }
         }
      }
#endif

      if( checking >= checklevel::expensive )
      {
         for( const auto& sel : selections )
         {
            if( !sharedvarsconflict( cl, sel. first, *sel. second. first ))
            {
               throw std::runtime_error( "should not happen" );
            }
         }
      }
 
      // From every lemma in selections, we will add all V/X
      // for which V does not occur in cl, and we will
      // not add the V/X whose V occurs in cl. 
      // This means that each cl/j can be skipped only if 
      // there is a lemma, s.t. for every shared variable V between
      // cl and the lemma, the value x for V in cl/j is not in  
      // V/X.

      for( size_t j = cl. initial. s0; j != cl. initial. s1; ++ j )
      { 
         bool fullconfl = false;
         for( auto p = selections. begin( ); 
                   p != selections. end( ) && !fullconfl; ++ p )
         {
            if( sharedvarsconflict( cl, j, *( p -> second ). first ))
               fullconfl = true;
         }

         if( !fullconfl )
         {
            if( !addprojection( result, cl, j, theta ))
               throw std::runtime_error( "could not project" );
         }
      }

      unsigned int cost = 1;
      for( const auto& sel : selections ) 
      {
         addnotshared( result, cl, *sel. second. first );
         if( sel. second. second + 1 >= cost )
            cost = sel. second. second + 1;
      }

      if( checking >= checklevel::cheap && 
          consistent( theta, lemma( result )))
      {
         throw std::runtime_error( "resolution created a consistent lemma" );
      }

      auto res = newlemma( result, cost );
      if( outputlevel >= 1 )
         std::cout << "Resolvent = " << res << "\n";

      return res; 
   }
 
}}


