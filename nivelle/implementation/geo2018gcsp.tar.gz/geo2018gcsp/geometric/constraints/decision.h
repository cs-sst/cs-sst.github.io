
// Written by Hans de Nivelle, June 2016.

#ifndef GEOMETRIC_CONSTRAINTS_DECISION_INCLUDED
#define GEOMETRIC_CONSTRAINTS_DECISION_INCLUDED  1

#include "newlemma.h"
#include <vector>

namespace geometric
{
namespace constraints 
{

   // A decision stores lemmas that were collected during 
   // branching before the current decisions. 
   // We also remember the number of solutions, so that we can
   // now if there have been solutions. 

   struct decision
   {
      long unsigned int nrsolutions;
         // So that we can check if subbranches had solutions.

      size_t tried; 
         // Number of choices which have been tried. For those, there
         // either exists a conflict lemma in the lemmasystem, or 
         // in our conflicts.

      std::vector< newlemma > conflicts;    
         // Lemmas that reject the choices that were already tried,
         // which are not in the lemma system. 

      explicit decision( size_t nrsolutions )
         : nrsolutions{ nrsolutions },
           tried{0} 
      { }

      void push_back( newlemma&& n ) 
         { conflicts. push_back( std::move(n)); }

      void push_back( lemma&& lem, unsigned int cost ) 
         { conflicts. emplace_back( std::move( lem ), cost ); } 

   };


   inline std::ostream& 
   operator << ( std::ostream& out, const decision& dec )
   {
      out << "Decision, ";
      out << "number of solutions = " << dec. nrsolutions << ", ";
      out << "number tried = " << dec. tried << "\n";

      for( const auto& n : dec. conflicts )
         out << "      " << n << "\n";
      return out;
   }

   inline std::ostream& 
   operator << ( std::ostream& out, const std::vector< decision > & dec )
   {
      out << "Decision stack:\n";
      for( const auto& d : dec )
         out << d << "\n";
      return out;
   }

}}

#endif


