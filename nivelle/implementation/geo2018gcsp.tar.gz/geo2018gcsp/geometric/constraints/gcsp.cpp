
// Written by Hans de Nivelle, Dec 2015.
// Rewritten in May 2016.

#include "gcsp.h"
#include <iomanip>

namespace geometric
{
namespace constraints
{

   void gcsp::clause::state::setfirst( long unsigned int rnd ) 
   {
      s0 = rnd % ( s1 - s0 ); 
      s1 = s0 + 1;
   } 


   void gcsp::clause::state::setnext( const state& orig )
   {  
      if( s1 == orig. s1 )  
      {
         s0 = orig. s0;
         s1 = orig. s0 + 1; 
      }
      else
      {
         ++ s0;
         s1 = s0 + 1;
      }
   }

 

   gcsp::clause::clause( const std::vector< variable > & domain,
               const std::vector< size_t > & matchings,
               const std::vector< const set< size_t > * > & alphas )
      : initial{0,0},
        current{0,0},
        domain{ domain }
   {
      if( domain. size( ) * alphas. size( ) != matchings. size( ))
         throw std::logic_error( "gcsp::gcsp sizes dont fit" );

      for( size_t j = 0; j != alphas. size( ); ++ j )
      {
         this -> matchings. push_back( alphas[j] );
         for( size_t i = 0; i < domain. size( ); ++ i )
            this -> matchings. back( ). values. push_back(
               matchings[ j * domain. size( ) + i ] );
      }
   }


   gcsp::clause::clause( const std::vector< variable > & domain,
                         size_t nrmatchings,
                         const std::vector< size_t > & matchings )
      : clause( domain, matchings,
                std::vector< const set< size_t > * > ( nrmatchings ))
   { }


   bool gcsp::clause::indomain( variable v ) const
   {
      for( auto w : domain )  
      {
         if( v == w ) return true;
      }
      return false;
   }




   void 
   gcsp::clause::set_current_from_alpha( bool bl, const set< size_t > * alpha )
   { 
      current = allmatchings( );

      size_t s = current. s0; 
      while( s < current. s1 )
      {
         bool included;

         if( matchings[s]. alpha )
         {
            if( alpha )
               included = subset( * matchings[s]. alpha, * alpha );
            else
               included = true;   // Absent == universal.
         }
         else
            included = ( alpha == nullptr ); 
               // If matchings[s]. alpha is universal, then alpha must be
               // universal too. 

         if( bl ? ( !matchings[s]. alpha || !included ) : included ) 
            ++ s; 
         else
            disable(s); 
      }

      initial = current;
   }


   void gcsp::occurrences::insert( size_t k )
   {
      if( !vect. size( ))
         vect. push_back(k);
      else
      {
         if( k < vect. back( )) 
            throw std::runtime_error( "occurrences not sorted" );
         if( k > vect. back( )) 
            vect. push_back(k); 
      }
   } 


   bool gcsp::occurrences::contains( size_t k ) const
   {
      size_t lower = 0;
      size_t upper = vect. size( );

      while( upper - lower > 4 )
      {
         size_t middle = lower + ( upper - lower ) / 2;

         if( vect[ middle ] <= k )
            lower = middle;
         else
            upper = middle;
      }

      // End with linear search:

      while( lower < upper )
      {
         if( vect[ lower ] == k )
            return true;

         ++ lower;
      }

      return false;
   }


   void gcsp::build_indices( )
   {
      for( size_t c = 0; c < clauses. size( ); ++ c ) 
      {
         for( size_t v = 0; v < clauses[c]. nrvars( ); ++ v ) 
            clauses_ind[ clauses[c]. var(v) ]. insert(c); 
      }

      for( size_t b = 0; b < blockings. size( ); ++ b )
      {
         for( size_t v = 0; v < blockings[b]. nrvars( ); ++ v ) 
           blockings_ind[ blockings[b]. var(v) ]. insert(b); 
      }

      for( size_t c = 0; c < clauses. size( ); ++ c )
      {
         for( size_t v = 0; v < clauses[c]. nrvars( ); ++ v )
         {
            variable var = clauses[c]. var(v);
            const occurrences& block = findblockings( var );

            // We enumerate the blockings in which var occurs:

            for( size_t b : block )
            {
               for( size_t w = 0; w < blockings[b]. nrvars( ); ++ w )
               {
                  variable connectedvar = blockings[b]. var(w);
                     // Enumerating the variables in the blocking.

                  // connectedvar is connected to var through a blocking
                  // and var occurs in c, so we can add c to 
                  // connections[ connectedvar ] if c is not in 
                  // clauses[ connectedvar ]. 
                  // included in cl (which is the level-1 index.)

                  if( !findclauses( connectedvar ). contains(c))
                  {
                     connections_ind[ connectedvar ]. insert( c );
                  }
               }
            }
         }
      }

   }



   std::ostream& 
   operator << ( std::ostream& out, const gcsp::occurrences& occ )
   {
      out << "{";
      for( auto p = occ. begin( ); p != occ. end( ); ++ p )
      {
         if( p != occ. begin( ))
            out << ", ";
         else
            out << " ";
         out << *p;
      }
      out << " }";
      return out; 
   }



   std::pair< size_t, size_t >
   gcsp::getblocked( const subststack< size_t > & theta, size_t s ) const
   {
      while( s < theta. size( )) 
      {
         variable v = theta[s]. first;

         const auto& occ = findblockings(v);
         for( size_t b : occ )
         {
            // These are all the blockings that contain variable v.
            // The blocking must be fully instantiated, and
            // must have a choice that is consistent with theta. 

            if( instantiates( theta, blockings[b] ))
            {
               for( size_t j = blockings[b]. current. s0; 
                           j < blockings[b]. current. s1; ++ j )
               {
                  if( consistent( theta, blockings[b], j ))
                     return { b, j };
               } 
            }
         }
         ++ s;
      }
      return { blockings. size( ), 0 }; 
   }


   bool gcsp::impliesblocked( const subststack< size_t > & theta,
                              const clause& cl, size_t j ) const
   {
      // Enumerate all variables that occur in cl:

      for( size_t i = 0; i < cl. nrvars( ); ++ i )
      {
         variable v = cl. var(i); 
         const auto& occ = findblockings(v);

         for( size_t b : occ )
         {
            // We are now enumerating all blockings that share a variable 
            // with cl. 

            // We check if each variable in blockings[b] is assigned in 
            // theta, or occurs in cl.

            bool checkable = true; 
            for( size_t c = 0; c < blockings[b]. nrvars( ) && checkable; ++ c )
            {
               variable w = blockings[b]. var(c); 

               if( !theta. lookup(w) && !cl. indomain(w) )
                  checkable = false; 
            }

            if( checkable )
            {
               // As far as I can see, it is sufficient
               // for the c-th choice, to be consistent
               // with theta and with cl/j.

               for( size_t c = blockings[b]. current. s0; 
                           c < blockings[b]. current. s1; ++ c )
               {
                  if( consistent( theta, blockings[b], c ) &&
                      consistent( cl, j, blockings[b], c ))
                  {
                     return true;
                  }
               }
            }
         }
      }

      return false;
   }


   void gcsp::initfromalpha( const set< size_t > * alpha )
   {
      for( auto& cl : clauses )
         cl. set_current_from_alpha( false, alpha );

      for( auto& bl : blockings )
         bl. set_current_from_alpha( true, alpha );  
   }


   size_t gcsp::pickshortest( ) const
   {
      size_t best = clauses. size( );
      size_t bestsize = 0;

      for( size_t cl = 0; cl < clauses. size( ); ++ cl )
      {
         size_t s = clauses[ cl ]. current. size( );

         if( s > 1 &&
             ( best == clauses. size( ) || s < bestsize ))
         {
            best = cl;
            bestsize = s;
         }

      }
      return best;
   }


   size_t gcsp::pickfirst( ) const
   {
      for( size_t cl = 0; cl < clauses. size( ); ++ cl )
      {
         size_t s = clauses[ cl ]. current. size( );
         if( s > 1 )
            return cl;
      }
      return clauses. size( ); 
   }


   void gcsp::write( std::ostream& out ) const
   {
      size_t uppvar = 0;     // upper bound of variables. 
      size_t uppval = 0;     // upper bound of values. 

      for( size_t cl = 0; cl < clauses. size( ); ++ cl )
      {
         for( size_t v = 0; v != clauses[cl]. nrvars( ); ++ v )
         {
            size_t var = clauses[cl].var(v). getindex( );
            if( var >= uppvar )
               uppvar = var + 1; 
         }

         for( size_t s = clauses[cl].current.s0; 
                     s != clauses[cl].current.s1;
                     ++ s )
         {
            for( size_t v = 0; v != clauses[cl]. nrvars( ); ++ v )
            {
               size_t val = clauses[cl]. value( v, s );   
               if( val >= uppval ) 
                  uppval = val + 1;
            } 
         }
      }

      out << "p gcsp " << uppvar << " " << uppval << " ";
      out << clauses. size( ) << " " << blockings. size( ) << "\n\n";

      // We can write the clauses:

      for( size_t cl = 0; cl != clauses. size( ); ++ cl )
         clauses[cl]. write( out );

      // And we write the blockings:

      for( size_t bl = 0; bl != blockings. size( ); ++ bl )  
         blockings[bl]. write( out );

      // A few newlines: 

      out << "\n\n"; 
   }


   namespace
   {

      gcsp::clause readclause( inputstream& input )
      {

         size_t nrvars = input. readunsigned( );
         input. skipwhitespace( );

         std::vector< variable > domain; 

         for( size_t v = 0; v != nrvars; ++ v )
         {
            size_t ind = input. readunsigned( );
            input. skipwhitespace( ); 
            domain. push_back( variable::fromindex( ind ));
         } 

         size_t nrchoices = input. readunsigned( );
         input. skipwhitespace( );
       
         std::vector< size_t > matchings;  

         for( size_t j = 0; j != nrchoices; ++ j )
            for( size_t v = 0; v != nrvars; ++ v )
            {
               size_t c = input. readunsigned( ); 
               input. skipwhitespace( );
               matchings. push_back( c );
            }
         
         return gcsp::clause( domain, nrchoices, matchings );   
      }
   }


   gcsp gcsp::read( inputstream& input )
   {
      input. skipwhitespace( );

      while( !input. eof( ) && 
             ( input.nextchar == 'c' || input. nextchar == 'C' ))
      {
         input. readcomment( );
         input. skipwhitespace( );
      }

      if( input. eof( ) || !inputstream::startidentifier( input. nextchar ))
      {
         throw syntax_error( "expected p gcsp " + input. inlineoffile( ));
      }

      auto p = input. readidentifier( );

      if( !inputstream::equalwithoutcase( p, "p" ))
         throw syntax_error( "expected p gcsp " + input. inlineoffile( ));

      input. skipwhitespace( ); 
      if( input. eof( ) || !inputstream::startidentifier( input. nextchar ))
         throw syntax_error( "expected p gcsp " + input. inlineoffile( ));

      p = input. readidentifier( );
      if( !inputstream::equalwithoutcase( p, "gcsp" ))
         throw syntax_error( "expected p gcsp " + input. inlineoffile( ));
      input. skipwhitespace( );

      size_t nrvars = input. readunsigned( ); 
      input. skipwhitespace( );
      size_t nrvalues = input. readunsigned( );
      input. skipwhitespace( );
      size_t nrclauses = input. readunsigned( );
      input. skipwhitespace( );
      size_t nrblockings = input. readunsigned( );
      input. skipwhitespace( );

      // std::cout << nrvars << " " << nrvalues << " ";
      // std::cout << nrclauses << " " << nrblockings << "\n";

      gcsp g;

      for( size_t cl = 0; cl != nrclauses; ++ cl )
      {
         g. clauses. push_back( readclause( input ));
         g. clauses. back( ). current = 
                 g. clauses. back( ). allmatchings( );
      }

      for( size_t bl = 0; bl != nrblockings; ++ bl )
      {
         g. blockings. push_back( readclause( input ));
         g. blockings. back( ). current = 
                 g. blockings. back( ). allmatchings( );
      }

      g. build_indices( ); 

      // std::cout << "next char " << (char) input. nextchar << "\n"; 
      // std::cout << "eof        " << input. eof( ) << "\n";

      return g; 
   }


   bool consistent( const subststack< size_t > & theta,
                    const gcsp::clause& cl, size_t j )
   {
      for( size_t v = 0; v != cl. nrvars( ); ++ v )
      {
         variable var = cl. var(v);
         size_t val = cl. value( v, j );

         const auto* p = theta. lookup( var );

         if( p && *p != val )
            return false;
      }
      return true;
   }


   bool consistent( const gcsp::clause& cl1, size_t j1, 
                    const gcsp::clause& cl2, size_t j2 )
   {
      for( size_t v1 = 0; v1 != cl1. nrvars( ); ++ v1 )
      {
         variable var1 = cl1. var( v1 );
         size_t val1 = cl1. value( v1, j1 );
        
         for( size_t v2 = 0; v2 != cl2. nrvars( ); ++ v2 )  
         {
            variable var2 = cl2. var( v2 );
            size_t val2 = cl2. value( v2, j2 );

            if( var1 == var2 )
               if( val1 != val2 ) return false;
            else
               goto found;   // Variables occur at most once.
         }
      found:
         ;  
      }
      return true;
   }


   bool match( subststack< size_t > & theta,
               const gcsp::clause& cl, size_t j )
   {
      for( size_t v = 0; v != cl. nrvars( ); ++ v )
      {
         variable var = cl. var(v);
         size_t val = cl. value( v, j );

         const auto* p = theta. lookup( var );
         if( !p )
            theta. assign( var, val );
         else
         {
            if( *p != val )
               return false;
         }
      }
      return true;
   }


   void extend_by_common( const gcsp::clause& cl,
                          subststack< size_t > & theta )
   {
#if 0
      if( cl. current. size( ) != 1 )
         return; 
#endif
 
      for( size_t v = 0; v < cl. nrvars( ); ++ v )
      {
         // No assignment yet? 
 
         if( !theta. lookup( cl. var(v) ))
         {
            size_t val = cl. value( v, cl. current. s0 );

            for( size_t i = cl. current. s0 + 1; i < cl. current. s1; ++ i )
            {
               if( cl. value( v, i ) != val )
                  goto dontagree;
            }

            theta. assign( cl. var(v), val );
         dontagree:
            ;
         }
      }
   }
   

   bool instantiates( const subststack< size_t > & theta,
                      const gcsp::clause& cl )
   {
      for( size_t v = 0; v != cl. nrvars( ); ++ v )
      {
         variable var = cl. var(v);

         // Every variable var in cl[i] must have assignment val: 

         const auto* p = theta. lookup( var );
         if( !p ) 
            return false;
      }
      return true;
   }


   bool gcsp::issolution( const subststack< size_t > & theta, 
                          bool tellreason ) const
   {
      for( size_t c = 0; c < clauses. size( ); ++ c )
      {
         if( !instantiates( theta, clauses[c] ))
         {
            if( tellreason )
               std::cout << "clause " << c << " is not fully instantiated\n";

            return false;
         }

         for( size_t j = clauses[c]. current. s0; 
                     j < clauses[c]. current. s1; ++ j )
         {
            if( consistent( theta, clauses[c], j ))
               goto found;
         }

         if( tellreason )
            std::cout << "clause " << c << " is not true\n";

         return false;  
      found:  
         ;
      }

      for( size_t b = 0; b < blockings. size( ); ++ b )
      {
         if( !instantiates( theta, blockings[b] ))
         {
            if( tellreason )
               std::cout << "blocking " << b << " is not fully instantiated\n"; 

            return false;
         }
      
         for( size_t j = blockings[b]. current. s0; 
                     j < blockings[b]. current. s1; ++ j )
         {
            if( consistent( theta, blockings[b], j ))
            {
               if( tellreason )
                  std::cout << "blocking " << b << "/" << j << " is true\n"; 

               return false; 
            }
         }
      }

      return true;
   }


   set< size_t >
   gcsp::getassumptions( const subststack< size_t > & theta ) const
   {
      set< size_t > alpha;

      for( size_t c = 0; c < clauses. size( ); ++ c )
      {
         for( size_t j = clauses[c]. current. s0; 
                     j < clauses[c]. current. s1; ++ j )
         {
            if( consistent( theta, clauses[c], j ))
               alpha |= clauses[c]. getalpha(j); 
         }
      }

      for( size_t b = 0; b < blockings. size( ); ++ b )
      {
         // The following probably requires some explanation: Blockings
         // in the current state are certainly not true. This follows from 
         // the fact that theta is a solution. Hence there is no point in 
         // looking at them. Choices outside our state are choices that 
         // would create a conflict that we currently allow. Even though 
         // we allow the conflict, we still have to include it. 

         clause::state all = blockings[b]. allmatchings( );
         clause::state current = blockings[b]. current;
     
         for( size_t j = all. s0; j < all. s1; ++ j )
         {
            if( !current. contains(j) && consistent( theta, blockings[b], j ))
            {
               alpha |= blockings[b]. getalpha(j);
            }

            // It follows from the fact that the clause was unusable,
            // that it carries an alpha. 
         }
      }

      return alpha; 
   }

   
   std::ostream& operator << ( std::ostream& out, const gcsp::matching& m )
   {
      out << "(";
      for( auto p = m. values. begin( ); p != m. values. end( ); ++ p )
      {
         if( p == m. values. begin( ))
            out << " ";
         else
            out << ", ";
         out << *p;
      }
      out << " )";

      if( m. alpha )
         out << "/" << *( m. alpha );

      return out;
   }


   void gcsp::clause::hard_commit( )
   {
      matchings. erase( matchings. begin( ) + current. s1, matchings. end( ));

      size_t s = current. s0;
      matchings. erase( matchings. begin( ), matchings. begin( ) + s );

      current. s0 -= s;
      current. s1 -= s;

      initial. s0 -= s;
      initial. s1 -= s;
   }


   void gcsp::clause::print( std::ostream& out ) const 
   {
      out << "(";

      for( size_t v = 0; v < nrvars( ); ++ v )
      {
         if( v == 0 ) 
            out << " ";
         else
            out << ", ";
         out << var(v); 
      }
      out << " ) ==> ";

      for( size_t j = current. s0; j < current. s1; ++ j ) 
      {
         if( j != current. s0 )
            out << " | ";
   
         out << j << ":" << matchings[j];
      }
   }


   void gcsp::clause::printvertically( std::ostream& out ) const
   {
      for( size_t v = 0; v < nrvars( ); ++ v )
      {
         out << ' ' << var(v) << "  ==> "; 
     
         size_t j = initial. s0;
         for( size_t j = initial. s0; j < initial. s1; ++ j )
         {
           
            out << '|' << std::setw(2) << value( v, j );
         }
         out << "|\n";
      }
   }

   void gcsp::clause::write( std::ostream& out ) const
   {
      out << domain. size( ) << " ";
      for( size_t v = 0; v < domain. size( ); ++ v )
         out <<  var(v). getindex( ) << " ";
      out << " ";
      out << current. size( ) << " ";
      for( size_t j = current. s0; j != current. s1; ++ j )
      {
         for( size_t v = 0; v < domain. size( ); ++ v )
            out << value( v, j ) << " ";
      }
      out << "\n";
   }

   std::ostream& operator << ( std::ostream& out, const gcsp& g )
   {
      out << "Generalized Constraint Solving Problem:\n";
      out << "---------------------------------------\n";
      out << "\n";

      out << "Clauses:\n";
      for( size_t nr = 0; nr < g. clauses. size( ); ++ nr )
         out << nr << " : " << g. clauses[ nr ] << "\n";
      out << "\n";

      out << "Blockings:\n";
      for( size_t nr = 0; nr < g. blockings. size( ); ++ nr )
         out << nr << " : " << g. blockings[ nr ] << "\n";
      out << "\n";

      out << "Clause Index:\n";
      for( const auto& c : g. clauses_ind )
      {
         out << "   ";
         out << c. first << ": ";
         out << c. second << "\n";
      } 
      out << "\n";

      out << "Blocking Index:\n";
      for( const auto& c : g. blockings_ind )
      {
         out << "   ";
         out << c. first << ": ";
         out << c. second << "\n";
      }
      out << "\n";

      out << "Connected (through Blocking) Index:\n";
      for( const auto& c : g. connections_ind )
      {
         out << "   ";
         out << c. first << ": ";
         out << c. second << "\n";
      }

      return out;
   }


}}




