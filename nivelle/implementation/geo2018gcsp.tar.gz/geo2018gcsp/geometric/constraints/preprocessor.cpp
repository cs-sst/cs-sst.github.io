
// Written by Hans de Nivelle, May 2016.

#include "preprocessor.h"
#include "resolution.h"
#include "refinement.h"
#include "../../checklevel.h"


namespace geometric
{
namespace constraints
{

   namespace 
   {
      static constexpr checklevel checking = checklevel::forfree;
      static constexpr unsigned int outputlevel = 0;
   }


   std::vector< refinement >
   allclauses( const gcsp& g, const subststack< size_t > & theta )
   {
      std::vector< refinement > log;

      for( size_t cl = 0; cl < g. clauses. size( ); ++ cl )
      {
         log. emplace_back( refinement( false, cl,
                            g. clauses[ cl ]. current,
                            g. clauses[ cl ]. current. size( ),
                            theta. size( ) ));
      }

      return log;
   }


   namespace
   {   

      // p must be not cl_rest. end( ). This must be checked before calling.

      bool hassolution( subststack< size_t > & theta,
                        const gcsp& g, 
                        const std::vector< size_t > & cl_rest,
                           std::vector< size_t > :: const_iterator p )
      {
         const size_t s = theta. size( );

         const auto& cl = g. clauses[ *p ];

         for( size_t i = cl. current. s0; i != cl. current. s1; ++ i )
         {
            if( match( theta, cl, i ))
            {
               ++ p;
               if( p == cl_rest. end( ) ||  
                   hassolution( theta, g, cl_rest, p ))
               {
                  return true;
               }
               -- p;
            }
            theta. restore(s); 
         }
         return false;
      }

   }

 
   bool hassolution( subststack< size_t > & theta,
                     const gcsp& g, 
                     size_t cl, size_t i,
                     const std::vector< size_t > & cl_rest ) 
   {
      const size_t s = theta. size( );

      if( match( theta, g. clauses[cl], i ))
      {
         if( cl_rest. size( ) == 0 )
         {
            throw std::runtime_error( "i believe that this cannot happen" );
            theta. restore(s);
            return true;
         }
         else
         {
            if( hassolution( theta, g, cl_rest, cl_rest. begin( )))
            {
               theta. restore(s);
               return true;
            }
         }
      }

      theta. restore(s);  
      return false;
   }
   


   namespace
   {

      // Try to refine clause cl against cl_rest. If a refinement is possible,
      // then it is appended to log, and we return true.
      // cl_rest can be empty.


      bool refine( size_t cl, const std::vector< size_t > & cl_rest,
                   subststack< size_t > & theta, gcsp& g, 
                   std::vector< refinement > & log )
      {
         if( outputlevel >= 2 )
         {
            std::cout << "trying to refine clause " << cl;
            std::cout << " against circle "; 
            print( std::cout, cl_rest );
            std::cout << "\n";
         }

         auto initial = g. clauses[cl]. current;

         size_t i = g. clauses[ cl ]. current. s0;
         while( i < g. clauses[ cl ]. current. s1 )
         {
            // Is cl/i consistent with theta and cl_rest?

            if( hassolution( theta, g, cl, i, cl_rest ))
               ++ i;
            else 
               g. clauses[cl]. disable(i);
         }

         if( initial. size( ) != g. clauses[cl]. current. size( ))
         {
            // Something was changed, so we write the change, which is sound
            // (not a decision) into log. 

            log. emplace_back( false, cl, 
                               initial, g. clauses[cl]. current. size( ), 
                               theta. size( ) );

            if( outputlevel >= 3 )
            {
               std::cout << "extended by " << ( log. size( ) - 1 ) << " : ";
               std::cout << log. back( ) << "\n\n"; 
            }

            extend_by_common( g. clauses[cl], theta );
            return true; 
         }
         else
            return false;
      }



      bool sharevariable( const gcsp::clause& cl1, const gcsp::clause& cl2 )
      {
         for( size_t v1 = 0; v1 < cl1. nrvars( ); ++ v1 )
         for( size_t v2 = 0; v2 < cl2. nrvars( ); ++ v2 )
         {
            if( cl1. var( v1 ) == cl2. var( v2 ))
               return true;
         }
         return false;
      }


      // S must be at least 1. We are considering the path
      // cl_middle;cl_last. Before refine is called, one should check
      // that { cl_middle, cl_last } is not in checked. 

      bool 
      refine( size_t cl, std::vector< size_t > & cl_middle, size_t cl_last,
              size_t S,
              checked& c, subststack< size_t > & theta,
              gcsp& g,
              std::vector< refinement > & log )
      {
         const gcsp::clause& last_clause = g. clauses[ cl_last ];

         if( outputlevel >= 2 )
         {
            std::cout << "trying to refine "; 
            std::cout << checked::path( cl_middle, cl_last );
            std::cout << " from clause " << cl << "\n";
         }

         if( cl_middle. size( ) + 1 == S )
         {
            // If S == 1, we are sure that last_clause and cl share a 
            // variable, so we don't check it.

            if( S == 1 || sharevariable( g. clauses[ cl ], last_clause ))
            {
               cl_middle. push_back( cl_last );   
               if( !c. contains( { cl_middle, cl } ))
               {
                  // Every clause d in cl_middle must be refined against
                  // ( cl_middle \ d ) + cl. 

                  auto ref = std::vector<size_t> ( S, 0 );

                  for( size_t r = 0; r < S; ++ r )
                  {
                     for( size_t i = 0; i < S; ++ i )
                     {
                        if( i == r )
                           ref[i] = cl;
                        else
                           ref[i] = cl_middle[i];
                     }

                     if( refine( cl_middle[r], ref, theta, g, log ))
                        return true; 

                  } 
                  c. insert( { cl_middle, cl } ); 
               }
               cl_middle. pop_back( ); 
            }
            return false;
         } 
         else
         {
            cl_middle. push_back( cl_last );

            for( size_t v = 0; v < last_clause. nrvars( ); ++ v )
            {
               const auto& occ = g. findclauses( last_clause. var(v) );
               for( auto next : occ )
               {  
                  if( next != cl && !contains( next, cl_middle )) 
                  {
                     if( !c. contains( { cl_middle, next } ))
                     {
                        if( refine( cl, cl_middle, next, 
                                    S, c, theta, g, log ))
                        {
                           return true;
                        }

                        c. insert( { cl_middle, next } );
                     }
                  }
               }               
            }

            cl_middle. pop_back( ); 
            return false;
         } 
      }


      // Refine clause cl against the substitution, and against
      // the substitution, taking blockings into account.
      // Return true if clause cl was changed. 

      bool refine0( size_t cl, subststack< size_t > & theta, gcsp& g,
                    std::vector< refinement > & log )
      {
         auto initial = g. clauses[cl]. current; 

         size_t i = g. clauses[ cl ]. current. s0;
         while( i < g. clauses[ cl ]. current. s1 )
         {
            if( consistent( theta, g. clauses[cl], i ) &&
                !g.impliesblocked( theta, g. clauses[cl], i ))
            {
               ++ i;
            }
            else
            {
               g. clauses[cl]. disable(i);            
            }
         }

         if( initial. size( ) != g. clauses[cl]. current. size( ))
         {
            log. emplace_back( false, cl, 
                               initial, g. clauses[cl]. current. size( ),
                               theta. size( ));

            extend_by_common( g. clauses[cl], theta );
            return true;
         }
         else
            return false;
      }


      // Refine cl against connected circles of size S. 
      // 
      // If S = 1, all pairs containing cl are checked.
      // If S = 2, all triangles containing cl are checked.
      // If S = 3, all squares containing cl are checked, etc.
      // If cl is changed, we return true and append the change to log.
      // If possible, we extend the substitution.
      // If no refinement is possible, we return false. 
      // 
      // This function does not take blockings into account. 

      bool refine( size_t cl, size_t S,
                   subststack< size_t > & theta, gcsp& g, 
                   std::vector< refinement > & log )
      {
         if( outputlevel >= 5 )
         {
            std::cout << "Refining circles of size " << S << " containing ";
            std::cout << "clause " << cl << " with theta = " << theta << "\n";
         }

         if( S == 0 ) throw std::runtime_error( "S cannot be zero" ); 

         std::vector< size_t > cl_middle;
         checked c;

         for( size_t v = 0; v < g. clauses[ cl ]. nrvars( ); ++ v )
         {
            const auto& occ = g. findclauses( g.clauses[ cl ]. var(v) );
            for( auto first : occ )
            {
               if( first != cl )
               {
                  if( !c. contains( { cl_middle, first } ))
                  {
                     if( refine( cl, cl_middle, first, S, c, theta, g, log ))
                        return true; 
                     c. insert( { cl_middle, first } );
                  }
               }
            }
         }

         return false; 
      }



      // Refine clauses in g, triggered by theta[ >= s ] and
      // log[ >= k ] until a stable position is reached.
      // When we create an empty clause, or discover that :w
      // last clause in log.


      bool
      preprocessor( gcsp& g, 
                    subststack< size_t > & theta, size_t s,
                    std::vector< refinement > & log, size_t k, 
                    size_t S ) 
      {

         if( outputlevel >= 2 )
         {
            std::cout << "\n";
            std::cout << "Starting Preprocessor:\n";
            std::cout << theta << " / " << s << "\n";
            std::cout << g << "\n";
            std::cout << log << "k = " << k << "\n\n";
         }

         auto kkkk = std::vector< size_t > ( S+1, k );
            // kkkk[i] = j means that circles up to size i have been checked
            // up to position j in log. 
            // kkkk[0] is not used.

      restart:
         if( outputlevel >= 4 ) 
         {
            std::cout << "restarting with " << theta << " at " << s << "\n";
            std::cout << "checked: "; print( std::cout, kkkk ); 
            std::cout << "/" << log. size( ) << "\n";
            if( log. size( ))
            {
               std::cout << "last change: clause " << log. back( ). cl;
               std::cout << " was refined into\n";
               std::cout << "   " << g. clauses[ log. back( ). cl ] << "\n";
            }
         }

         // First check if theta implies a blocking:

         if( s < theta. size( ))
         {
            auto bl = g. getblocked( theta, s );
            if( bl. first != g. blockings. size( ))
               return false;  
         }
 
         // Check for direct clashes against the substitution,
         // and for clashes involving a blocking:

         while( s < theta. size( ))
         {
            variable v = theta[s]. first;

            const auto& occ = g. findclauses(v);
            for( auto c : occ )
            {
               if( refine0( c, theta, g, log ))
               {
                  if( !g. clauses[ log. back( ). cl ]. current. size( ))
                     return false;
               }
            }

            const auto& con = g. findconnections(v);
            for( auto c : con )
            {
               if( refine0( c, theta, g, log ))
               {
                  if( !g. clauses[ log. back( ). cl ]. current. size( ))
                     return false;
               }
            }

            ++ s;
         }

         // Find smallest unchecked subset size for which we have
         // unchecked changes:

         for( size_t i = 1; i <= S; ++ i )
         {
            while( kkkk[i] < log. size( ))
            {
               if( log[ kkkk[i] ]. iscurrent(g))
               {
                  size_t cl = log[ kkkk[i] ]. cl;
                  if( refine( cl, i, theta, g, log ))
                  {
                     if( !g. clauses[ log. back( ). cl ]. current. size( ))
                        return false; 
                     goto restart; 
                  }
               }
               ++ kkkk[i];
            }
         }

         // No unchecked changes. That means that we reached a fixed point.

         return true; 
      }


   }


   bool preprocessor( gcsp& g, subststack< size_t > & theta, size_t S )
   {

      if( outputlevel ) 
      {
         std::cout << "\n";
         std::cout << "Entering preprocessor(" << S << "):\n";
         std::cout << theta << "\n";
         std::cout << g << "\n";
         std::cout << "(this was while entering preprocessor)\n"; 
      }

      // Check for blockings with empty domain:

      for( size_t b = 0; b < g. blockings. size( ); ++ b )
      {
         if( g. blockings[b]. nrvars( ) == 0 &&
             g. blockings[b]. current. size( ))
         {
            return false;
         }
      }

      // Remove substlets that imply a blocking from the clauses: 

      for( size_t c = 0; c < g. clauses. size( ); ++ c )
      {
         size_t j = g. clauses[c]. current. s0;
         while( j < g. clauses[c]. current. s1 )
         {
            if( g. impliesblocked( theta, g. clauses[c], j ))
               g. clauses[c]. disable(j);
            else
               ++ j;  
         }

         if( g. clauses[c]. current. size( ) == 0 )
            return false;
               // We discovered an empty clause.

         // Check if we can extend the substitution.
         // (When there is a variable in g. clauses[c] for which the
         //  assignments agree.) 

         extend_by_common( g. clauses[c], theta ); 
      }

      auto stack = allclauses( g, theta );

      if( !preprocessor( g, theta, 0, stack, 0, S ))
      {
         if( outputlevel ) std::cout << "preprocessor rejects\n";
         return false;
      }

      if( checking >= checklevel::expensive )
      {
         stack = allclauses( g, theta );
         auto ss = stack. size( );

         if( !preprocessor( g, theta, 0, stack, 0, S ) || ss != stack. size( ))
         {
            std::cout << "preprocessor failed to reach a fixed point\n";
            std::cout << g;
            std::cout << stack << "\n";
 
            throw std::logic_error(  
               "preprocessor failed to reach a fixed point" );
         }
      }
  
      if( outputlevel ) std::cout << "preprocessor accepts\n";
      return true; 
   }


}}


