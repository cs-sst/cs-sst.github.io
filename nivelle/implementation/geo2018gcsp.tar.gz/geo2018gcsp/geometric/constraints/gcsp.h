
// Written by Hans de Nivelle, December 2015.
// Rewritten in May 2016:
//    I added backtracking support to gcsp::clause, and
//    removed class choicestack.

#ifndef GEOMETRIC_CONSTRAINTS_GCSP_INCLUDED
#define GEOMETRIC_CONSTRAINTS_GCSP_INCLUDED  1

#include <vector>

#include "../set.h"
#include "subststack.h"
#include "inputstream.h"

namespace geometric
{
namespace constraints 
{

   class gcsp
   {

      struct matching
      {
         std::vector< size_t > values; 
         const set< size_t > * alpha;
            // We are not owner! The alphas are probably part of an 
            // interpretation. Blockings that originate from a true 
            // conclusion have no alpha. 

         matching( const set< size_t > * alpha )
            : alpha{ alpha }
         { }
      };

      friend std::ostream& operator << ( std::ostream& , const matching& ); 

   public: 
      class clause
      {
         std::vector< variable > domain;     
         std::vector< matching > matchings;

      public: 
         struct state
         {
            size_t s0;
            size_t s1;

            state( size_t s0, size_t s1 )
               : s0{s0}, s1{s1}
            { }

            bool contains( size_t s ) const { return s >= s0 && s < s1; }
            bool included_in( state s ) const
               { return s0 >= s.s0 && s1 <= s.s1; }
            bool disjoint_with( state s ) const
               { return ( s0 >= s.s0 ? s0 : s.s0 ) >=
                        ( s1 <= s.s1 ? s1 : s.s1 ); }

            size_t size( ) const { return s1 - s0; }

            void setfirst( long unsigned int rnd );  
               // Refine into size 1, using rnd as pseudo random base.

            void setnext( const state& orig );
               // Advance by 1, restarting at beginning if we reach end. 
               // For this, we need orig. 
         };


         state initial;   // State that is used for lemma derivation.
                          // Initial is not used in blockings.
         state current;   // Current state during search. 
            // All search algorithms must have invariant that no
            // matchings outside the current state interval are moved. 
            // Also, it seems reasonable that current is a subinterval of
            // initial. 
            // Exchanging matchings inside current is possible. 

         clause( const std::vector< variable > & domain,
                 const std::vector< size_t > & matchings,
                 const std::vector< const set< size_t > * > & alpha );

         clause( const std::vector< variable > & domain,
                 size_t nrmatchings,
                 const std::vector< size_t > & matchings );
            // The only reason that parameter nrmatchings exists, is
            // the possibility that domain. size( ) == 0.

         size_t nrvars( ) const { return domain. size( ); }
         variable var( size_t i ) const { return domain[i]; }

         bool indomain( variable v ) const;
           // True if variable v is in our domain.

         size_t value( size_t v, size_t j ) const
            { return matchings[j]. values[v]; }
               // Value for the v-th variable in the j-th choice.

         bool hasalpha( size_t j ) const
            { return matchings[j]. alpha; }

         const set< size_t > getalpha( size_t j ) const
            { return *matchings[j]. alpha; } 

         void disable( size_t i )
         {
            -- current. s1;
            if( i != current. s1 )
               std::swap( matchings[i], matchings[ current. s1 ] );
         }
            // Disable the i-th choice, by swapping it with the last
            // element in current. This will decrease current.s1 by one.
            // If you want to check many choices, do:
            // i = current.i0; while( i < current.i1 ) 
            //    if( i is OK ) i++; else disable(i); 
            // If you have a list of elements to delete, you must
            // do it backwards:
            // i = current.i1; while( i != current.i0 ) 
            //    --i;  disable(i);
        
         void set_current_from_alpha( bool bl, const set< size_t > * alpha );
            // Set the current and the initial state using alpha. A nullptr 
            // is treated as a universal alpha (containing everything).
            // If we are not a blocking, the alpha of the matching
            // must be included in the parameter alpha. 
            // If we are a blocking, we must have empty alpha, or our
            // alpha must be not included in the parameter alpha. 
            // This is Definition 20 in the paper.
            // Note that we use disable( ), so that matchings can be  
            // permuted. 

         state allmatchings( ) const { return { 0, matchings. size( ) }; }
            // All matchings in the clause. 

         void hard_commit( );
            // Permanently delete the substlets that are not in our initial
            // state. 

         void print( std::ostream& ) const; 

         void printvertically( std::ostream& ) const;
            // Print clause (in its initial state) in the form: 
            // X | x1 y1
            // Y | x2 y1
            // Z | x3 y2

         void write( std::ostream& out ) const;
            // Write the clause (current state) as a sequence of numbers,
            // nrvars nrchoices V1 ... VN choice1 ... choiceM,
            // followed by a newline. Each choice is a sequence of
            // size_ts of length N.

      };


      std::vector< clause > clauses;
      std::vector< clause > blockings;
         // Blockings are not clauses in strict sense because they   
         // do not have disjunctive meaning. It is still convenient
         // to represent them as clauses because avoids originating
         // from the same conclusion have the same set of variables. 
         // 
         // If a value in a blocking has no assumption set, 
         // then the blocking should be always used.
         // If a value has an assumption set, then the blocking should 
         // be used when its assumption set is not included in the current 
         // assumption set. 

   private: 
      // Strictly increasing vector of occurrences of a variable:

   public: 
      struct occurrences
      {
         std::vector< size_t > vect;

         occurrences( ) { } 

         void insert( size_t k );
            // Expects and preserves the fact that we are
            // strictly sorted. 

         bool contains( size_t k ) const;
            // True if we contain k. 

         // Only const iteration:

         std::vector< size_t > :: const_iterator begin( ) const
            { return vect. cbegin( ); }
         std::vector< size_t > :: const_iterator end( ) const
            { return vect. cend( ); } 
      };
   
      friend std::ostream& operator << ( std::ostream& , const occurrences& );

   private: 
      using varindex = variablemap< occurrences > ;

      varindex clauses_ind;
      varindex blockings_ind; 
      varindex connections_ind;  
         // cl in connections[v] if there exists a blocking that contains 
         // v and a variable of cl, and cl not in blockings[v].
      
      void build_indices( );
         // Build the indices.

      gcsp( ) { }

   public: 
      const occurrences& findclauses( variable v ) const
         { return clauses_ind. at(v); } 

      const occurrences& findblockings( variable v ) const 
         { return blockings_ind. at(v); } 

      const occurrences& findconnections( variable v ) const
         { return connections_ind. at(v); }

      std::pair< size_t, size_t >
      getblocked( const subststack< size_t > & theta, size_t s ) const;
         // If theta (involving a recent change >= s ) 
         // implies a blocking, we return such a blocking.
         // Otherwise, we return ( blockings. size( ), 0 ). 
 
      bool impliesblocked( const subststack< size_t > & theta, size_t s ) const
         { return getblocked( theta, s ). first < blockings. size( ); }

         // True if one of the recent assignments (>= s),
         // possibly together with older assignments implies a 
         // blocked clause. There must be a recent assignment involved, 
         // in order to avoid rechecks during backtracking.

      bool impliesblocked( const subststack< size_t > & theta,
                           const clause& cl, size_t j ) const;
         // True if theta combined with cl/j implies a blocking.
         // Note that we assume that theta and cl/j are consistent.
         // Consistency between theta and cl/j must be checked 
         // separately.

      void initfromalpha( const set< size_t > * alpha ); 
         // Using alpha, initialize the current states in the 
         // clauses and in the blockings. Note that initial states
         // are not initialized. Use set_initials( ) for this. 

      bool issolution( const subststack< size_t > & theta,
                       bool tellreason = false ) const;
         // True if theta is a solution. If tellreason is true,
         // we print the reason why it is not a solution, in case
         // of returning false. 

      set< size_t > 
      getassumptions( const subststack< size_t > & theta ) const;
         // Get the assumption set of a given theta.
         // It is obtained from the usable clauses that are made true
         // by theta, and the unusable blockings that are made true. 
         // theta must be a solution! 

      void set_initials( )
         { for( auto& cl : clauses ) cl. initial = cl. current; }
            // Set the initial states of the clauses equal to the current
            // states. This should be done after preprocessing. 
      
      void hard_commit( ) 
         { for( auto& cl : clauses ) cl. hard_commit( ); } 
            // Permantenly remove all substlets that are not current
            // from the clauses. Blockings are not touched. 
            // initials and current are adopted. This method may move 
            // substlets.
  
      size_t pickshortest( ) const;
         // Pick a shortest clause that has size( ) > 1.
         // Return clauses.size( ) if no such clause exists.

      size_t pickfirst( ) const;
         // Pick the first clause that has size( ) > 1.
         // Return clauses.size( ) if no such clause exists.

      void write( std::ostream& out ) const;
      static gcsp read( inputstream& input );
         // What was written by write( ), can be read back by read( ).

      friend std::ostream& operator << ( std::ostream& out, const gcsp& g );
   };


   bool consistent( const subststack< size_t > & theta,
                    const gcsp::clause& cl, size_t j );
      // True if subst is consistent with cl/j.

   bool consistent( const gcsp::clause& cl1, size_t j1, 
                    const gcsp::clause& cl2, size_t j2 );
      // True if cl1/j1 and cl2/j2 do not have conflicting assignments.

   bool match( subststack< size_t > & theta,
               const gcsp::clause& cl, size_t j );
      // Attempt to extend theta in such a way that it implies cl/j.
      // Note that theta may still be extended in case of failure!

   void extend_by_common( const gcsp::clause& cl, 
                          subststack< size_t > & theta );
      // Extend theta by the common assignments in cl.
      // (If X = 3 in all choices, and undefined in theta,  
      //  we add X := 3 to theta.)
      // We assume that cl was filtered, so that all assignments
      // are consistent with theta. 

   bool instantiates( const subststack< size_t > & theta, 
                      const gcsp::clause& cl );
      // True if subst instantiates all variables in cl.

   std::ostream& operator << ( std::ostream& out, const gcsp::matching& m );


   inline std::ostream&
   operator << ( std::ostream& out, const gcsp::clause::state s )
   {
      out << "[ " << s. s0 << " .. " << s. s1 << " )";
      return out;
   }


   inline std::ostream& 
   operator << ( std::ostream& out, const gcsp::clause& cl )
   {
      cl. print( out );
      return out;
   }

   std::ostream& operator << ( std::ostream& out, const gcsp::occurrences& );
   std::ostream& operator << ( std::ostream& out, const gcsp& g );

}}

#endif

