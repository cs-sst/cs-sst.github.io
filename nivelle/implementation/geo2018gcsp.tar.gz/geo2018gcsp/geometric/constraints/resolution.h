
// Written by Hans de Nivelle, April-June 2016.
// Lemma/clause resolution, as described in the IJCAR 2016 paper.

#ifndef GEOMETRIC_CONSTRAINTS_RESOLUTION_INCLUDED
#define GEOMETRIC_CONSTRAINTS_RESOLUTION_INCLUDED  1

#include <vector>
#include <iostream>

#include "subststack.h"
#include "lemmasystem.h"
#include "newlemma.h" 


namespace geometric 
{
namespace constraints 
{

   lemma 
   sigma_resolvent( const gcsp& g, const gcsp::clause& bl, size_t j );
      // Create a sigma-resolvent resulting from the blocking bl/j.
      // For every variable V in the blocking, we pick a clause in g
      // that contains V. We collect the possible assignments to 
      // V in g, and remove the value in the blocking.
      // If g has been filtered in advance, the result should be independent
      // on the clauses selected. 
      // Change to return outcome?

   bool 
   sharedvarsconflict( const gcsp::clause& cl, size_t j, const lemma& lem );
      // True if ALL variables of lem that occur in cl/j can be resolved
      // away. This means that the value X for V in cl/j, does not
      // occur among the possible values for V in lem. 

   void addnotshared( lemma::builder& res,
                      const gcsp::clause& cl, 
                      const lemma& lem );
      // For every V/X in lem, for which V does not occur in the domain 
      // of cl, add V/X into the builder.

   bool addprojection( lemma::builder& res,
                       const gcsp::clause& cl, size_t j,
                       const subststack< size_t > & theta );
      // If cl/j conflicts theta, then add a projection to res.
      // Return true if this happened.

   std::vector< newlemma > :: const_iterator
   findconflict( const subststack< size_t > & theta, 
                 const std::vector< newlemma > & conflset );
      // If there is a lemma in conflset that is in conflict with theta,
      // we return the shortest.

   newlemma resolvent( const gcsp::clause& cl,
                       subststack< size_t > & theta, 
                       const gcsp& g, 
                       lemmasystem& sys,
                       const std::vector< newlemma > & subconfl );
      // For every substlet j in cl. initial, one of the following must hold:
      //    - cl/j conflicts theta. 
      //    - theta + cl/j makes a lemma in sys false,
      //    - theta + cl/j makes a lemma in subconfl false,
      //    - theta + cl/j implies a blocking. 

}}

#endif

