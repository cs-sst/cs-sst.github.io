
#ifndef GEOMETRIC_CONSTRAINTS_SUBSTSTACK_DEFINED
#define GEOMETRIC_CONSTRAINTS_SUBSTSTACK_DEFINED   1

#include "../variable.h"
#include "../variablemap.h"

#include <iostream>
#include <functional>


namespace geometric 
{ 
namespace constraints 
{

   template< typename D >
   class subststack
   {
      
      variablemap< std::pair< bool, D >> index;
      std::vector< std::pair< variable, D >> stack;

   public:
      subststack( ) 
      { }

      void clear( )
      {
         index. clear( );
         stack. clear( );
      }

      void assign( variable v, const D& d )
      {
         stack. emplace_back( v, d );
         index[v] = std::pair< bool, D > ( true, d ); 
      }

      const std::pair< variable, D > & operator [] ( size_t i ) const
         { return stack[i]; } 

      void print( std::ostream& out ) const;

      const D* lookup( variable v ) const;

      size_t size( ) const { return stack. size( ); }
         
      void restore( size_t k )
      {
         while( stack. size( ) > k ) 
         {
            index[ stack. back( ). first ]. first = false;
            stack. pop_back( );
         }
      }

      template< typename D1 > 
      subststack< D1 > 
      convertrange( const std::function< D1(D) > & conv ) const;
         // Convert the range to type D1. 
         //    For every assignment v := d, the result has v := conv(d). 

   };


   template< typename D >
   const D* subststack<D> :: lookup( variable v ) const
   {
      if( index. indomain(v))
      {
         const auto& p = index[v];

         if( p. first ) 
            return & p. second;
         else
            return nullptr;
      }
      else
         return nullptr;
   }


   template< typename D >
   void subststack<D> :: print( std::ostream& out ) const
   {
      out << "subststack( " << stack. size( );
      if( stack. size( )) out << ';';

      for( auto p = stack. begin( ); p != stack. end( ); ++ p )
      {
         if( p != stack. begin( ))
            out << ", ";
         else
            out << " ";
         out << ( p -> first ) << " := " << ( p -> second );
      }
      out << " )";

#if 0
      out << "\nVariable Map:\n";
      for( const auto& p : index )  
      {
         if( p. second. first ) 
            out << "   " << p. first << " --> " << p. second. second << "\n";
      }
#endif
   }

   template< typename D > 
   template< typename D1 > 
   subststack< D1 > 
   subststack< D > :: convertrange( 
             const std::function< D1(D) > & conv ) const
   {
      subststack<D1> res; 
      for( auto p = stack. cbegin( ); p != stack. cend( ); ++ p )
         res. assign( p -> first, conv( p -> second ));

      return res; 
   }

   template< typename D >
   std::ostream& operator << ( std::ostream& out, const subststack<D> & s )
   {
      s. print( out );
      return out;
   }

}}


#endif


