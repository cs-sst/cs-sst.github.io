
// Written by Hans de Nivelle, June 2016.

// Checked contain the sets that a choice (a substlet in a clause)
// has been checked against. We could not come up with a reasonable
// way of avoiding that different subsets are enumerated twice, so
// the best way seems just to store them in a hashmap. 

#ifndef GEOMETRIC_CONSTRAINTS_CHECKED_INCLUDED
#define GEOMETRIC_CONSTRAINTS_CHECKED_INCLUDED  1

#include <vector>
#include <unordered_set> 
#include <iostream>


namespace geometric
{
namespace constraints 
{

   inline bool contains( size_t s, const std::vector< size_t > & set )
   {
      for( auto i : set )
         if( s == i ) return true;
      return false;
   }

   inline size_t nr_occurrences( size_t s, const std::vector< size_t > & set )
   {
      size_t nr = 0; 
      for( auto i : set ) 
         if( i == s )
            ++ nr; 
      return nr; 
   } 
   
   inline void print( std::ostream& out, const std::vector< size_t > & set )
   {
      out << "[";
      for( auto p = set. begin( ); p != set. end( ); ++ p )
      {
         if( p != set. begin( ))
            out << ",";
         out << *p;
      }
      out << "]";
   }


   struct checked
   {

      // A path consists of a set of visited nodes, and 
      // the last one.

      struct path
      {
         std::vector< size_t > visited; // Treated as set. 
         size_t last;
  
         path( const std::vector< size_t > & visited, size_t last )
            : visited{ visited },
              last{ last }
         { }

         path( std::vector< size_t > && visited, size_t last )
            : visited{ std::move(visited) },
              last{ last }
         { }

      };

 
      // Both hasher and equality must be order independent.
      // I gave them both multiset semantics. 

      struct hasher
      {
         size_t operator( ) ( const path& pp ) const;
      };

      struct equality 
      {
         // Method is quadratic, but the vectors are short:

         bool operator( ) ( const path& pp1, const path& pp2 ) const;
      };

      std::unordered_set< path, hasher, equality > map;
 
      bool contains( const path& pp ) const
         { return map. find( pp ) != map. end( ); } 

      void insert( const path& pp ) 
         { map. insert( pp ); }  

      size_t size( ) const { return map. size( ); } 

   };

   std::ostream& operator << ( std::ostream& , const checked::path& pp );
   std::ostream& operator << ( std::ostream& , const checked& c );
          
}}

#endif

