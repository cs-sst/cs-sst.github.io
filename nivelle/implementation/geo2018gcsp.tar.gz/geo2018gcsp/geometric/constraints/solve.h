
// Written by Hans de Nivelle, Jan-June 2016.
// A few solvers, both learning and non-learning, and squeezing. 

#ifndef GEOMETRIC_CONSTRAINTS_SOLVE_INCLUDED
#define GEOMETRIC_CONSTRAINTS_SOLVE_INCLUDED  1

#include <memory>

#include "gcsp.h"
#include "refinement.h"
#include "preprocessor.h"
#include "lemmasystem.h"
#include "outcome.h"
#include "resolution.h"
#include "../../statistics/timer.h"

namespace geometric
{
namespace constraints 
{

   void checklemmastate( const gcsp* g, 
                         const subststack< size_t > * theta,
                         const lemmasystem& sys );
      // Check the state, and throw an exception if the state is not
      // good.

   namespace naive
   { 
      void solve( const gcsp& g, subststack< size_t > & theta,
                  size_t& nrsolutions, size_t level ); 

   }


   namespace notlearning
   {

      bool forward( gcsp& g,
                    subststack< size_t > & theta, size_t s,
                    std::vector< refinement > & stack );

      void solve( gcsp& g, subststack< size_t > & theta,
                  std::vector< refinement > & stack, size_t& nrsolutions );

   }


   // An improvement of the Geo 2007 algorithm: 

   namespace learning
   {

      outcome refine( gcsp& g, size_t cl,
                      lemmasystem& sys, subststack< size_t > & theta,
                      std::vector< refinement > & stack,
                      const lemma& forw, lemma::const_iterator p );

      // Try to refine clause g.clauses[cl] against theta,
      // considering theta and g. blockings: 

      outcome refine( gcsp& g, size_t cl,
                      lemmasystem& sys, subststack< size_t > & theta,
                      std::vector< refinement > & stack );
      
      // 1. theta does not imply a blocking.
      // 2. theta up to s_imm does not imply a lemma. 
      // 3. theta up to s_ref cannot simplify a clause. 

      outcome forward( gcsp& g, lemmasystem& sys,
                       subststack< size_t > & theta, 
                       size_t s_imm, size_t s_ref, 
                       std::vector< refinement > & stack );

      outcome decide( gcsp& g, lemmasystem& sys,
                      subststack< size_t > & theta, size_t& nrsolutions );
   }


   // bestsolution calls solve, which is the interface to the
   // other matching algorithms.
   // If stopfirst == true, then solve either finds no solution
   // and returns 0, or it finds 1 solution, and keeps
   // it in theta.

   long unsigned int solve( gcsp& g, subststack< size_t > & theta );

   std::unique_ptr< subststack< size_t >> bestsolution( gcsp& g );    
      // List contains 0 or 1 elements.
      // g cannot be const, because we sometimes reset the usable  
      // choices in g. 

}}

#endif


