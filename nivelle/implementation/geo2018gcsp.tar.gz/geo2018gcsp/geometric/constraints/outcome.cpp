
// Written by Hans de Nivelle, Nov 2016.

#include "outcome.h"

namespace geometric
{
namespace constraints 
{

   std::ostream& operator << ( std::ostream& out, const outcome& res )
   {
      switch( res.t )
      {
      case outcome::type::nolemma:
         out << "(nolemma)\n";
         return out;

      case outcome::type::reusedlemma:
         out << "reusedlemma(" << res. index << ")";
         return out;

      case outcome::type::newlemma:
         out << "new " << ( res. created -> lem );
         out << " with cost " << ( res. created -> cost ) << "\n";
         return out;
      }

      throw std::runtime_error( "reached the unreachable" ); 
   }


   void 
   outcome::check_learn( lemmasystem& sys,
                         const subststack< size_t > & theta,
                         unsigned int maxcost )
   {
      if( t == type::newlemma && getcost( ) > maxcost )
      {
         if( false ) 
            std::cout << "   learning[ " << sys. nrlemmas( ) << " ]\n";

         index = sys. insert( theta, getcost( ), std::move( created -> lem ));
         t = type::reusedlemma;
         created = nullptr;
      }
   }

}}


