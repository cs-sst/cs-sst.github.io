
// Written by Hans de Nivelle, June 2016.
// refining was finished in November 2016.

#include "solve.h"
#include "resolution.h"
#include "decision.h"
#include "cnf.h"

#include "../../statistics/reporter.h"
#include "../../checklevel.h"
#include "../../tostring.h"


namespace geometric
{
namespace constraints 
{

   namespace
   {

      static constexpr checklevel checksolutions = checklevel::forfree;
         // Checking correctness of solutions can be costly when there are
         // many.

      static constexpr checklevel checking = checklevel::forfree;

      static constexpr unsigned int outputlevel = 0;
         // Higher number means more output.
         // 0 : print nothing.
         // 1 : print one in 100000 solutions.
         // 2 : print all solutions.
         // 3 : print incredible amount of trash. 

      static constexpr bool stopfirst = true;
         // Makes the matching algorithms stop on the first solution.
         // Otherwise, all solutions get enumerated. 
         // Normal operation should stop on the first solution,
         // because squeezing will find the optimal solution.

      static constexpr unsigned int maxcost = 5;

   }


   void solution( const gcsp& g, const subststack< size_t > & theta,
                  size_t& nrsolutions )
   {
      if( outputlevel )
      {
         if( outputlevel > 1 || nrsolutions % 10000 == 0 )
         {
            std::cout << "Solution " << nrsolutions << ":\n";
            std::cout << theta << "\n\n";
         }
      }

      if( checksolutions >= checklevel::expensive && 
          !g. issolution( theta, true ))
      {
         std::cout << "-------------------------\n";
         std::cout << g << "\n";
         std::cout << theta << "\n";

         std::cout << "substitution is not a solution!\n\n";
         throw std::runtime_error( "reported incorrect solution!\n" );
      }

      ++ nrsolutions;
   }


   void naive::solve( const gcsp& g,
                      subststack< size_t > & theta, 
                      size_t& nrsolutions,
                      size_t level )
   {
      if( level == g. clauses. size( ))
         solution( g, theta, nrsolutions ); 
      else
      {
         size_t s = theta. size( );

         for( size_t j = g. clauses[ level ]. current. s0; 
                     j < g. clauses[ level ]. current. s1; ++ j )
         {
            if( match( theta, g. clauses[ level ], j ) && 
                !g. impliesblocked( theta, s ))
            {
               solve( g, theta, nrsolutions, level + 1 );
            }

            if( nrsolutions && stopfirst )
               return;

            theta. restore(s);
         }
      }
   }


   // Try to simplify g. clauses[ cl ] against theta,
   // using conflicts against theta and blockings.  
   // We extend theta, whenever possible. 
   // If g. clauses[ cl ] becomes empty, we create a lemma.

   outcome 
   learning::refine( gcsp& g, size_t cl,
                     lemmasystem& sys,
                     subststack< size_t > & theta, 
                     std::vector< refinement > & stack )
   {

      if( outputlevel >= 4 )
      {
         std::cout << "\n";
         std::cout << "Refining " << g. clauses[cl] << "\n";
         std::cout << "against " << theta << "\n";
      }

      // It cannot be a for loop, because we either delete or 
      // move to the next:

      auto original_state = g. clauses[cl]. current;

      size_t i = g. clauses[cl]. current. s0; 
      while( i != g. clauses[cl]. current. s1 )
      {
         if( consistent( theta, g. clauses[cl], i ) &&
             !g.impliesblocked( theta, g. clauses[cl], i ))
         {
            ++ i;
         }
         else
         {
            g. clauses[cl]. disable(i);
         }
      }

      if( original_state. size( ) != g. clauses[cl]. current. size( ))
      {
         if( g. clauses[cl]. current. size( ) == 0 )
         {
            std::vector< newlemma > subconfl;   
               // Not used, but required by resolvent.
 
            g. clauses[cl]. current = original_state; 
               // Restore clause. We didn't push it on the stack.

            return resolvent( g. clauses[cl], theta, g, sys, subconfl );
         }

         stack. emplace_back( false, cl, original_state,
                              g. clauses[cl]. current. size( ),
                              theta. size( ));

         size_t ssss = theta. size( );

         extend_by_common( g. clauses[cl], theta );

         if( theta. size( ) > ssss )
         {
            if( outputlevel >= 7 )
            {
               std::cout << "Extended substitution from " << ssss << " into ";
               std::cout << theta << "\n";
            }
         }
      }

      return outcome( );    // Denotes: No conflict.
   }



   // 1. theta does not imply a blocking.
   // 2. theta up to s_imm does not imply a lemma. 
   // 3. theta up to s_ref cannot simplify a clause.

   outcome learning::forward( gcsp& g, lemmasystem& sys, 
                              subststack< size_t > & theta, 
                              size_t s_imm, size_t s_ref,
                              std::vector< refinement > & stack )
   {
   restart: 
      if( s_imm < s_ref )
         throw std::runtime_error( "refine was preferred over immediate" );

      if( checking >= checklevel::expensive && 
                g. impliesblocked( theta, s_ref ))
      {
         throw std::runtime_error( "theta implies a blocking" );
      } 

      if( checking >= checklevel::insane &&
                g. impliesblocked( theta, 0 ))
      {
         throw std::runtime_error( "theta implies a blocking" ); 
      } 
      
      if( s_imm < theta. size( ))
      { 
         // We give preference to checking for reusable lemmas: 

         size_t reused = sys. findconflict( theta, s_imm );
         if( reused < sys. nrlemmas( ))
            return outcome( reused );

         s_imm = theta. size( );
      }

      while( s_ref < theta. size( )) 
      {
         variable v = theta[ s_ref ]. first;

         const auto& occ = g. findclauses(v);
         for( auto c : occ )
         {
            outcome out = refine( g, c, sys, theta, stack );  
            if( out ) return out; 

            if( s_imm < theta. size( )) goto restart;  
         }
     
         const auto& con = g. findconnections(v);
         for( auto c : con )
         {
            outcome out = refine( g, c, sys, theta, stack );
            if( out ) return out;

            if( s_imm < theta. size( )) goto restart; 
         }

         ++ s_ref; 
      }

      return outcome( );
   }

   namespace
   {

      // Returns the number of assignments to a variable in the domain of lem,
      // after (and including) at stack[k].

      size_t nruses( const std::vector< refinement > & stack, size_t k,
                     const subststack< size_t > & theta, const lemma& lem )
      {
         if( k >= stack. size( )) throw std::runtime_error( "k is too big" );

         size_t uses = 0;
         for( size_t s = stack[k]. subst_restore; s != theta. size( ); ++ s )
         {
            variable var = theta[s]. first;
            if( lem. hasindomain( var ))
               ++ uses;
         }
         return uses;
      }


      void backtrack_solution( gcsp& g, subststack< size_t > & theta,
                            std::vector< refinement > & stack )
      {
         while( stack. size( ) && !stack. back( ). dec )
         {
            size_t cl = stack. back( ). cl; 
            g. clauses[cl]. current = stack. back( ). previous;
            theta. restore( stack. back( ). subst_restore ); 

            stack. pop_back( );
         }
      }


      void backtrack_confl( outcome& confl,
                         gcsp& g, subststack< size_t > & theta,
                         std::vector< refinement > & stack,
                         lemmasystem& sys ) 
      {  
         if( outputlevel >= 4 )
         {
            std::cout << "Unwind conflict " << confl << "\n";
            std::cout << stack << "\n";
            std::cout << theta << "\n\n";
         }

         while( stack. size( ) && !stack. back( ). dec )
         {
            size_t u = nruses( stack, stack. size( ) - 1, theta,
                               confl. getlemma( sys ));
            theta. restore( stack. back( ). subst_restore );

            if(u)
            {
               confl. check_learn( sys, theta, maxcost );

               std::vector< newlemma > subconfl;
 
               if( confl. t == outcome::type::newlemma ) 
                  subconfl. push_back( std::move( confl ). getnewlemma( ));

               confl = resolvent( g. clauses[ stack. back( ). cl ],
                            theta, g, sys, subconfl ); 
            }
      
            // Restore main clause:
 
            g. clauses[ stack. back( ). cl ]. current 
                  = stack. back( ). previous;
            stack. pop_back( );
         }

         if( checking >= checklevel::cheap && 
                  consistent( theta, confl. getlemma( sys )))
         {
            throw std::runtime_error( "unwind returns non-conflict" ); 
         }

         if( outputlevel >= 4 )
         {
            std::cout << "exiting from backtrack_confl\n";
            std::cout << theta << "\n";
            std::cout << confl << "\n";
         }
      }
   }


   // We assume that the input has been preprocessed and filtered,
   // so that we can immediately start with guessing.

   outcome
   learning::decide( gcsp& g, lemmasystem& sys, 
                     subststack< size_t > & theta, 
                     size_t& nrsolutions )
   {
      if( checking >= checklevel::insane )
         sys. checkstate( theta );

      if( checking >= checklevel::insane &&
          g. impliesblocked( theta, 0 ))
      {
         throw std::logic_error( "decide: theta implies blocking" );
      }
      
      std::vector< refinement > stack;
      std::vector< decision > decisions;

      long unsigned int branchbase = 0;
      outcome confl;

      // Pick a clause that we will decide:
   pick: 
      {
         size_t picked = g. pickshortest( ); 

         if( picked == g. clauses. size( ))
         {
            solution( g, theta, nrsolutions ); 

            if( stopfirst ) return outcome( );
            backtrack_solution( g, theta, stack );

            if( stack. size( ) == 0 ) return outcome( );

            theta. restore( stack. back( ). subst_restore );

            // Advance current of last clause to next option:

            g. clauses[ stack. back( ). cl ]. current. 
                                  setnext( stack. back( ). previous );

            ++ decisions. back( ). tried; 

            goto trydecision;
         }

         auto current = g. clauses[ picked ]. current;
  
         decisions. push_back( decision( nrsolutions )); 

         stack. emplace_back( true, picked, current, 1, theta. size() ); 
         g. clauses[ picked ]. current. setfirst(0);

      }
   trydecision:
      // stack[ stack.back( ) ]. cl is refined, but may be empty. 
      // theta. size( ) = stack[ stack. back ]. restore subst.

      if( checking >= checklevel::cheap && stack. size( ) == 0 )
         throw std::runtime_error( "should not happen" ); 

      if( checking >= checklevel::cheap &&
             theta. size( ) != stack. back( ). subst_restore )
      {
         throw std::runtime_error( "should not happen" );
      }

      if( decisions. back( ). tried == stack. back( ). previous. size( ))
      {

         // We reached the last choice. 

         size_t picked = stack. back( ). cl;

         g. clauses[ picked ]. current = stack. back( ). previous;
            // Restore picked clause.

         // If there have been solutions, we cannnot derive a lemma.

         if( nrsolutions != decisions. back( ). nrsolutions )
         {
            decisions. pop_back( ); 
            stack. pop_back( );
 
            backtrack_solution( g, theta, stack );
            if( stack. size( ) == 0 ) return outcome( );

            theta. restore( stack. back( ). subst_restore );

            // Advance current of last clause to next choice:

            g. clauses[ stack. back( ). cl ]. current.
                                  setnext( stack. back( ). previous );

            ++ decisions. back( ). tried;  
            goto trydecision; 
         }

         confl = resolvent( g. clauses[ picked ],
                            theta, g, sys, decisions. back( ). conflicts ); 
     
         confl.created -> cost = 1000;

         stack. pop_back( ); 
         decisions. pop_back( ); 
            
         goto backtrack;
      } 

      {
         size_t s = theta. size( );
         size_t cl = stack. back( ). cl;
 
         // This cannot happen, because we have filtered against
         // conflicts and blockings: 

         if( !match( theta, g. clauses[ cl ], g. clauses[ cl ]. current. s0 ))
         {
            std::cout << "theta " << theta << "\n";
            throw std::runtime_error( "choice could not be matched" );
         }

         if( checking >= checklevel::expensive && 
             g. impliesblocked( theta, s ))
         {
            auto bl = g. getblocked( theta, s );
            std::cout << bl. first << " " << bl. second << "\n"; 
            throw std::runtime_error( "blocking was not filtered correctly" ); 
         }

         // If we have a lemma, we move on to the next choice.
         // This can happen, because forward does not consider 
         // lemmas.  
         // The last false parameter means that we are not interested in
         // finding the best conflict lemma. 

         if( outputlevel >= 4 )
         {
            std::cout << "Last Decision " << decisions. size( ) << ":\n";
            std::cout << decisions. back( ); 
            std::cout << g. clauses[cl] << "\n";
            std::cout << theta << "\n\n\n";
         }

         if( sys. findconflict( theta, s ) != sys. nrlemmas( ) || 
                findconflict( theta, decisions. back( ). conflicts ) != 
                  decisions. back( ). conflicts. end( ))
         {
            g. clauses[cl]. current. setnext( stack. back( ). previous ); 
               // advance clause cl to next.

            ++ decisions. back( ). tried; 

            theta. restore(s); 
            goto trydecision;
         }

         // Try forward reasoning. We know that 
         // theta does not imply a lemma or blocking:

         confl = forward( g, sys, theta, theta. size( ), s, stack );
            // We know that theta does not imply a blocking and
            // does not make a lemma false. 
        
         if( !confl ) goto pick;

         // confl contains a conflict lemma, we unwind.
      }
 
   backtrack: 
      backtrack_confl( confl, g, theta, stack, sys );

      if( stack. size( ) == 0 )
      {
         if( decisions. size( ))
         {
            throw std::runtime_error( "there are decisions left" );
         }

         if( checking >= checklevel::cheap &&
             consistent( theta, confl. getlemma( sys )))
         {
            throw std::runtime_error( "final lemma not in conflict" );
         }

         return confl;
      }

      if( decisions. size( ) == 0 )
         throw std::runtime_error( "there should have been decisions" );

      size_t u = nruses( stack, stack. size( ) - 1, theta, 
                         confl. getlemma( sys ));

      theta. restore( stack. back( ). subst_restore );

      // If confl did not use any variables from the last choice, we
      // continue at backtrack.

      if( !u ) 
      {
         g. clauses[ stack. back( ). cl ]. current = stack. back( ). previous; 

         stack. pop_back( ); 
         decisions. pop_back( ); 
      
         goto backtrack;  
      }

      confl. check_learn( sys, theta, maxcost );

      if( confl. t == outcome::type::newlemma )
      {  
         if( checking >= checklevel::expensive ) 
         {
            for( const auto& ll : decisions. back( ). conflicts )
            {
               if( ll. lem. subsumes( confl. getlemma( sys )))
                  throw std::runtime_error( "adding subsumed lemma to confl" );
            }
         }

         if( checking >= checklevel::insane &&
             sys. subsumes( confl. getlemma( sys ))) 
         {
            throw std::runtime_error( "adding subsumed lemma to conf" );
         }
         
         decisions. back( ). conflicts. push_back( 
             std::move( confl). getnewlemma( ));
      }
     
      g. clauses[ stack. back( ). cl ]. 
         current. setnext( stack. back( ). previous );

      ++ decisions. back( ). tried;

      goto trydecision;
   }


   long unsigned int solve( gcsp& g, subststack< size_t > & theta )
   {

      static double nextreport = 1.0E-4;
      static long unsigned int nrreported = 0;
 
      lemmasystem sys;
      long unsigned int nrsolutions = 0;

#if 1
      // It cannot be done with if, because if creates a scope.
      // The timer below must exist until after matching is 
      // completed. 

      statistics::timer t{ [&g, &theta, &sys, &nrsolutions]( double d ) 
      {
         return 0;

         if( d >= nextreport )
         {
            std::string name = "hard";
            if( nrreported < 10 ) name += "0";
            name += tostring( nrreported ); 
            
            auto printheader = []( std::ostream& out, double t,
                                   long unsigned int nrsolutions ) 
            {
               out << "c hard matching problem created by geo\n";
               out << "c it took " << t << " seconds to solve\n";
               if( nrsolutions )
                  out << "c SATISFIABLE\n";
               else
                  out << "c UNSATISFIABLE\n";  
               out << "\n";
            };
            
            {
               std::ofstream out{ name + ".dim" };
               printheader( out, d, nrsolutions ); 
               g. write( out );
            }
 
            {
               std::ofstream out{ name + ".cnf" };
               printheader( out, d, nrsolutions );
               auto trans = translate2cnf(g);
               out << trans << "\n"; 
            }
          
            while( d >= nextreport )
               nextreport *= 2;
            ++ nrreported;
         } 
      }};
#endif

      std::vector< refinement > stack;
      auto res = learning::decide( g, sys, theta, nrsolutions );

      if( outputlevel >= 1 )
      {
         std::cout << res << "\n";
         std::cout << sys << "\n";
         sys. printstatistics( std::cout );
      }

      return nrsolutions;
   }


   std::unique_ptr< subststack< size_t >> bestsolution( gcsp& g )
   {
      static unsigned int nr_calls = 0;  
         // How often we (bestsolution) were called.  
      static unsigned int nr_preprocessor = 0; 
         // How often the preprocessor was called. 
      static unsigned int nr_solve = 0;
         // How often solve was called.
      static unsigned int nr_hadmatching = 0;
         // How of instances that had at least one matching.

      ++ nr_calls; 

      {
         static statistics::reporter r;
         if( r. mustreport( ))
         {
            std::cout << "Report from bestsolution:\n";
            std::cout << "   number of calls                     = ";
                      std::cout << nr_calls << "\n";
            std::cout << "   number of preprocessor calls        = "
                      << nr_preprocessor << "\n"; 
            std::cout << "   number of calls to solve            = "
                      << nr_solve << "\n";
            std::cout << "   number where matching succeeded     = "
                      << nr_hadmatching << "\n\n";
 
            std::cout << "   "; r. printduration( std::cout );
            r. wasreported( );

            std::cout << "\n\n";
         }
      }

      g. initfromalpha( nullptr );

      subststack< size_t > theta;

      ++ nr_preprocessor; 

      const size_t S = 2;

      if( !preprocessor( g, theta, S )) 
         return { }; 

      g. set_initials( );
      g. hard_commit( );    
       
      size_t s = theta. size( );
         // We know that theta must be included in 
         // every solution. In the future, we will restore theta to s. 

      ++ nr_solve;
      size_t nrsolutions = solve( g, theta ); 

      if( nrsolutions )
      {
         ++ nr_hadmatching;
         if( checksolutions >= checklevel::expensive && 
             !g.issolution( theta, true ))
         {
            throw std::runtime_error( "wrong solution" );
         }

         auto best_theta = theta; 
         set< size_t > alpha = g. getassumptions( best_theta );

         // std::cout << "the first solution has: " << alpha << "\n";
         // std::cout << "best theta = " << best_theta << "\n";
 
         if( alpha. size( ) == 0 )
            return std::unique_ptr< subststack< size_t >> 
               { new subststack< size_t > ( std::move( best_theta )) }; 
               // We won't find better. 

         size_t k = alpha. max( ) + 1;

         while(k)
         {
            -- k; 

            if( alpha[k] )
            {
               // std::cout << "considering " << k << "\n";
               // std::cout << "alpha = " << alpha << "\n";

               auto alpha2 = alpha;
               alpha2. erase(k);
               for( size_t j = 0; j < k; ++ j )
                  alpha2. insert(j);

               g. initfromalpha( &alpha2 );
               theta. restore(s);

               ++ nr_preprocessor; 
               if( preprocessor( g, theta, S ))
               {
                  // std::cout << "Made it through the first checks:\n";
                  // std::cout << cs << "\n";
                  // std::cout << theta << "\n";

                  g. set_initials( ); 

                  ++ nr_solve;
                  nrsolutions = solve( g, theta );

                  if( nrsolutions ) 
                  {
                     ++ nr_hadmatching;

                     best_theta = theta;
                     alpha = g. getassumptions( best_theta );
                     // std::cout << "alpha became " << alpha << "\n";
                  }
               }
            }
         }

         return std::unique_ptr< subststack< size_t >>
            { new subststack< size_t > ( std::move( best_theta )) };
      }
      else
         return nullptr; 
   } 

}}


