The Maude files in this directory have been developed by Antonio Cerone.


This file contains instruction on running MAUDE on the 2 case studies
contained in this directory.


The MAUDE system can be downloaded at

http://maude.cs.illinois.edu/w/index.php?title=Maude_download_and_installation


Documentation on MAUDE is available at

http://maude.cs.illinois.edu/w/index.php?title=The_Maude_System#Maude_Documentation

The first three chapter of the Maude Primer are sufficient to understand
the two case studies (but does not include anything about model checking).
For the model-checking refers to Chapter 10 of the Maude Manual.

MAUDE can also be used with an ECLIPSE plugin.

To run the two case studies you can either uncomment the “load” commands at the beginning of all files (when present) and then directly run one of the three files:

- case-01-driving-pedestrian.maude (driving example)
- case-02-atm-new.maude (ATM with modern interface)
- case-02-atm-old.maude (ATM with old interface)

or

- First load all files that define the cognitive architecture,
  one by one in the following order
  1. topology.maude
  2. time.maude
  3. entities.maude
  4. memory.maude
  5. rewrite-rules.maude
- Then load one of the three case-study files above.






